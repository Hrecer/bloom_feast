package com.bloom_feast.events;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.bloom_feast.BloomFeastMainJava;

import java.util.Random;

@Mod.EventBusSubscriber(modid = BloomFeastMainJava.MOD_ID)
public class VineBreakEvent {
    private static final Random RANDOM = new Random();
    private static final double VANILLA_DROP_CHANCE = 0.20;

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        Block block = event.getState().getBlock();

        if (block == Blocks.VINE) {
            Player player = event.getPlayer();
            if (player == null) {
                return;
            }

            ItemStack heldItem = player.getMainHandItem();
            if (heldItem.is(Items.SHEARS)) {
                return;
            }

            if (RANDOM.nextDouble() < VANILLA_DROP_CHANCE) {
                ItemStack vanillaStack = new ItemStack(
                    BuiltInRegistries.ITEM.get(ResourceLocation.tryBuild("bloom_feast", "vanilla")), 1
                );
                if (event.getLevel() instanceof net.minecraft.world.level.Level level) {
                    Block.popResource(level, event.getPos(), vanillaStack);
                }
            }
        }
    }
}

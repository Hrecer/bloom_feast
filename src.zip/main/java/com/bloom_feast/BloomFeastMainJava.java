package com.bloom_feast;

import com.bloom_feast.bonnyfood.BonnyFoodInit;
import com.bloom_feast.deliciousdelights.init.DDBlockInit;
import com.bloom_feast.deliciousdelights.init.DDItemInit;
import com.bloom_feast.fastfood.init.ModBlocks;
import com.bloom_feast.fastfood.init.ModCreativeTabs;
import com.bloom_feast.fastfood.init.ModItems;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootTableReference;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.LootTableLoadEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.List;

@Mod(BloomFeastMainJava.MOD_ID)
public class BloomFeastMainJava {
    public static final String MOD_ID = "bloom_feast";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

    // 定义充能和超能食物的效果
    private static final MobEffectInstance[] POWERED_EFFECTS = {
        new MobEffectInstance(MobEffects.ABSORPTION, 2400, 1),
        new MobEffectInstance(MobEffects.REGENERATION, 600, 3),
        new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0),
        new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 0)
    };

    private static final MobEffectInstance[] OVERPOWERED_EFFECTS = {
        new MobEffectInstance(MobEffects.DAMAGE_BOOST, 1200, 0),
        new MobEffectInstance(MobEffects.ABSORPTION, 4800, 3),
        new MobEffectInstance(MobEffects.REGENERATION, 900, 0),
        new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 7800, 0),
        new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 7200, 2),
        new MobEffectInstance(MobEffects.NIGHT_VISION, 8400, 0)
    };

    // 充能食物: 6饥饿, 48饱和度
    public static final RegistryObject<Item> POWERED_BREAD = registerFood("powered_bread", 6, 8.0F, POWERED_EFFECTS);

    // 超能食物: 8饥饿, 80饱和度
    public static final RegistryObject<Item> OVERPOWERED_APPLE = registerFood("overpowered_apple", 8, 10.0F, OVERPOWERED_EFFECTS);

    private static RegistryObject<Item> registerFood(String name, int nutrition, float saturation, MobEffectInstance[] effects) {
        return ITEMS.register(name, () -> new FoodItem(nutrition, saturation, effects));
    }

    public BloomFeastMainJava() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // 注册 Bloom Feast 原物品
        ITEMS.register(modEventBus);

        // 注册DeliciousDelights方块（先注册方块）
        DDBlockInit.register(modEventBus);

        // 注册DeliciousDelights物品（后注册物品，因为种子需要引用作物方块）
        DDItemInit.ITEMS.register(modEventBus);
        DDItemInit.CREATIVE_TABS.register(modEventBus);

        ModItems.ITEMS.register(modEventBus);
        ModBlocks.BLOCKS.register(modEventBus);
        ModCreativeTabs.TABS.register(modEventBus);

        BonnyFoodInit.init();

        modEventBus.addListener(this::onBuildCreativeTabContents);

        // 注册村民交易事件
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onBuildCreativeTabContents(BuildCreativeModeTabContentsEvent event) {
        // 将充能面包和超能苹果添加到原版"食物与饮品"标签页
        if (event.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
            event.accept(POWERED_BREAD);
            event.accept(OVERPOWERED_APPLE);
        }
    }

    @SubscribeEvent
    public void onVillagerTrades(VillagerTradesEvent event) {
        if (event.getType() == VillagerProfession.FARMER) {
            List<VillagerTrades.ItemListing> trades = event.getTrades().get(1);
            
            // 农民1级交易 - 绿宝石购买种子
            trades.add((trader, rand) -> new MerchantOffer(
                new ItemStack(Items.EMERALD, 1),
                new ItemStack(DDItemInit.TEA_SEEDS.get(), rand.nextInt(2) + 1),
                16, 2, 0.05F
            ));
            trades.add((trader, rand) -> new MerchantOffer(
                new ItemStack(Items.EMERALD, 1),
                new ItemStack(DDItemInit.STRAWBERRY_SEEDS.get(), rand.nextInt(2) + 1),
                16, 2, 0.05F
            ));
            trades.add((trader, rand) -> new MerchantOffer(
                new ItemStack(Items.EMERALD, 1),
                new ItemStack(DDItemInit.MINT_SEEDS.get(), rand.nextInt(2) + 1),
                16, 2, 0.05F
            ));
            trades.add((trader, rand) -> new MerchantOffer(
                new ItemStack(Items.EMERALD, 1),
                new ItemStack(DDItemInit.RICE_SEEDS.get(), rand.nextInt(2) + 1),
                16, 2, 0.05F
            ));
            trades.add((trader, rand) -> new MerchantOffer(
                new ItemStack(Items.EMERALD, 1),
                new ItemStack(DDItemInit.BLUEBERRY_SEEDS.get(), rand.nextInt(2) + 1),
                16, 2, 0.05F
            ));
            trades.add((trader, rand) -> new MerchantOffer(
                new ItemStack(Items.EMERALD, 1),
                new ItemStack(DDItemInit.CHERRY_SEEDS.get(), rand.nextInt(2) + 1),
                16, 2, 0.05F
            ));
            trades.add((trader, rand) -> new MerchantOffer(
                new ItemStack(Items.EMERALD, 1),
                new ItemStack(DDItemInit.GINGER_SEEDS.get(), rand.nextInt(2) + 1),
                16, 2, 0.05F
            ));
            trades.add((trader, rand) -> new MerchantOffer(
                new ItemStack(Items.EMERALD, 1),
                new ItemStack(DDItemInit.BLACKBERRY_SEEDS.get(), rand.nextInt(2) + 1),
                16, 2, 0.05F
            ));
            trades.add((trader, rand) -> new MerchantOffer(
                new ItemStack(Items.EMERALD, 1),
                new ItemStack(DDItemInit.ANISE_SEEDS.get(), rand.nextInt(2) + 1),
                16, 2, 0.05F
            ));
        }
    }

    @SubscribeEvent
    public void onLootTableLoad(LootTableLoadEvent event) {
        ResourceLocation name = event.getName();
        
        // 注入到所有村庄箱子战利品表
        if (name.equals(BuiltInLootTables.VILLAGE_PLAINS_HOUSE) ||
            name.equals(BuiltInLootTables.VILLAGE_DESERT_HOUSE) ||
            name.equals(BuiltInLootTables.VILLAGE_SAVANNA_HOUSE) ||
            name.equals(BuiltInLootTables.VILLAGE_SNOWY_HOUSE) ||
            name.equals(BuiltInLootTables.VILLAGE_TAIGA_HOUSE) ||
            name.equals(BuiltInLootTables.VILLAGE_ARMORER) ||
            name.equals(BuiltInLootTables.VILLAGE_BUTCHER) ||
            name.equals(BuiltInLootTables.VILLAGE_CARTOGRAPHER) ||
            name.equals(BuiltInLootTables.VILLAGE_FISHER) ||
            name.equals(BuiltInLootTables.VILLAGE_FLETCHER) ||
            name.equals(BuiltInLootTables.VILLAGE_MASON) ||
            name.equals(BuiltInLootTables.VILLAGE_SHEPHERD) ||
            name.equals(BuiltInLootTables.VILLAGE_TANNERY) ||
            name.equals(BuiltInLootTables.VILLAGE_TEMPLE) ||
            name.equals(BuiltInLootTables.VILLAGE_TOOLSMITH) ||
            name.equals(BuiltInLootTables.VILLAGE_WEAPONSMITH)) {
            
            LootTable table = event.getTable();
            
            // 添加种子战利品池
            LootPool.Builder poolBuilder = LootPool.lootPool()
                .setRolls(ConstantValue.exactly(1))
                .add(LootTableReference.lootTableReference(new ResourceLocation(MOD_ID, "chests/village_seeds")))
                .setBonusRolls(ConstantValue.exactly(0));
            
            table.addPool(poolBuilder.build());
        }
    }

    public static class FoodItem extends Item {
        private final MobEffectInstance[] effects;

        public FoodItem(int nutrition, float saturation, MobEffectInstance[] effects) {
            super(new Item.Properties()
                    .food(new FoodProperties.Builder()
                            .nutrition(nutrition)
                            .saturationMod(saturation)
                            .build()));
            this.effects = effects;
        }

        @Override
        public ItemStack finishUsingItem(ItemStack stack, net.minecraft.world.level.Level world, net.minecraft.world.entity.LivingEntity entity) {
            ItemStack retval = super.finishUsingItem(stack, world, entity);
            for (MobEffectInstance effect : effects) {
                entity.addEffect(effect);
            }
            return retval;
        }
    }
}

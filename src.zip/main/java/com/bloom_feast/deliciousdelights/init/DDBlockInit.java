package com.bloom_feast.deliciousdelights.init;

import com.bloom_feast.BloomFeastMainJava;
import com.bloom_feast.deliciousdelights.block.DDCakeBlock;
import com.bloom_feast.deliciousdelights.block.crop.*;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class DDBlockInit {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, BloomFeastMainJava.MOD_ID);

    // ========== 作物方块 ==========
    public static final RegistryObject<Block> TEA_CROP = BLOCKS.register("tea_crop", TeaCropBlock::new);
    public static final RegistryObject<Block> STRAWBERRY_CROP = BLOCKS.register("strawberry_crop", StrawberryCropBlock::new);
    public static final RegistryObject<Block> MINT_CROP = BLOCKS.register("mint_crop", MintCropBlock::new);
    public static final RegistryObject<Block> RICE_CROP = BLOCKS.register("rice_crop", RiceCropBlock::new);
    public static final RegistryObject<Block> BLUEBERRY_CROP = BLOCKS.register("blueberry_crop", BlueberryCropBlock::new);
    public static final RegistryObject<Block> CHERRY_CROP = BLOCKS.register("cherry_crop", CherryCropBlock::new);
    public static final RegistryObject<Block> GINGER_CROP = BLOCKS.register("ginger_crop", GingerCropBlock::new);
    public static final RegistryObject<Block> BLACKBERRY_CROP = BLOCKS.register("blackberry_crop", BlackberryCropBlock::new);
    public static final RegistryObject<Block> ANISE_CROP = BLOCKS.register("anise_crop", AniseCropBlock::new);

    // ========== 蛋糕方块 ==========
    public static final RegistryObject<Block> VANILLA_FROSTED_VANILLA_CAKE = registerCakeBlock("vanilla_frosted_vanilla_cake", () -> DDItemInit.VANILLA_FROSTED_VANILLA_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> CHOCOLATE_FROSTED_VANILLA_CAKE = registerCakeBlock("chocolate_frosted_vanilla_cake", () -> DDItemInit.CHOCOLATE_FROSTED_VANILLA_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> STRAWBERRY_FROSTED_VANILLA_CAKE = registerCakeBlock("strawberry_frosted_vanilla_cake", () -> DDItemInit.STRAWBERRY_FROSTED_VANILLA_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> VANILLA_FROSTED_CHOCOLATE_CAKE = registerCakeBlock("vanilla_frosted_chocolate_cake", () -> DDItemInit.VANILLA_FROSTED_CHOCOLATE_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> CHOCOLATE_FROSTED_CHOCOLATE_CAKE = registerCakeBlock("chocolate_frosted_chocolate_cake", () -> DDItemInit.CHOCOLATE_FROSTED_CHOCOLATE_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> STRAWBERRY_FROSTED_CHOCOLATE_CAKE = registerCakeBlock("strawberry_frosted_chocolate_cake", () -> DDItemInit.STRAWBERRY_FROSTED_CHOCOLATE_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> MINT_FROSTED_CHOCOLATE_CAKE = registerCakeBlock("mint_frosted_chocolate_cake", () -> DDItemInit.MINT_FROSTED_CHOCOLATE_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> CHOCOLATE_MOUSSE_CAKE = registerCakeBlock("chocolate_mousse_cake", () -> DDItemInit.CHOCOLATE_MOUSSE_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> VANILLA_CHEESE_CAKE = registerCakeBlock("vanilla_cheese_cake", () -> DDItemInit.VANILLA_CHEESE_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> CHOCOLATE_CHEESE_CAKE = registerCakeBlock("chocolate_cheese_cake", () -> DDItemInit.CHOCOLATE_CHEESE_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> COFFEE_CAKE = registerCakeBlock("coffee_cake", () -> DDItemInit.COFFEE_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> VANILLA_RED_VELVET_CAKE = registerCakeBlock("vanilla_red_velvet_cake", () -> DDItemInit.VANILLA_RED_VELVET_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> CHOCOLATE_RED_VELVET_CAKE = registerCakeBlock("chocolate_red_velvet_cake", () -> DDItemInit.CHOCOLATE_RED_VELVET_CAKE_SLICE.get(), 1);
    public static final RegistryObject<Block> SPONGE_CAKE = registerCakeBlock("sponge_cake", () -> DDItemInit.SPONGE_CAKE_SLICE.get(), 1);

    private static RegistryObject<Block> registerCakeBlock(String name, Supplier<Item> sliceItem, int sliceCount) {
        return BLOCKS.register(name, () -> new DDCakeBlock(sliceItem, sliceCount));
    }

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
    }
}

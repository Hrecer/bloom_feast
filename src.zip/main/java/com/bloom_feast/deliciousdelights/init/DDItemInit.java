package com.bloom_feast.deliciousdelights.init;

import com.bloom_feast.BloomFeastMainJava;
import com.bloom_feast.deliciousdelights.item.DDSeedItem;
import com.bloom_feast.deliciousdelights.item.base.DDCandyBase;
import com.bloom_feast.deliciousdelights.item.base.DDDrinkBase;
import com.bloom_feast.deliciousdelights.item.base.DDFoodBase;
import com.bloom_feast.deliciousdelights.item.base.DDItemBase;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class DDItemInit {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, BloomFeastMainJava.MOD_ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BloomFeastMainJava.MOD_ID);

    // ========== 基础物品 ==========
    public static final RegistryObject<Item> EMPTY_CUP = ITEMS.register("empty_cup", () -> new DDItemBase("empty_cup", 16));
    public static final RegistryObject<Item> EMPTY_TEA_BAG = ITEMS.register("empty_tea_bag", () -> new DDItemBase("empty_tea_bag"));
    public static final RegistryObject<Item> MORTAR = ITEMS.register("mortar", () -> new DDItemBase("mortar", true));
    public static final RegistryObject<Item> BUTTER_CHURN = ITEMS.register("butter_churn", () -> new DDItemBase("butter_churn", true));
    public static final RegistryObject<Item> KNIFE = ITEMS.register("knife", () -> new DDItemBase("knife"));
    public static final RegistryObject<Item> GRATER = ITEMS.register("grater", () -> new DDItemBase("grater"));
    public static final RegistryObject<Item> SPIGOT = ITEMS.register("spigot", () -> new DDItemBase("spigot"));

    // ========== 咖啡相关 ==========
    // 基础咖啡豆已移除，使用 Pam HC2 Crops 的 pamhc2crops:coffeebeanitem
    public static final RegistryObject<Item> MOCHA_COFFEE_BEANS = ITEMS.register("mocha_coffee_beans", () -> new DDItemBase("mocha_coffee_beans"));
    public static final RegistryObject<Item> ESPRESSO_COFFEE_BEANS = ITEMS.register("espresso_coffee_beans", () -> new DDItemBase("espresso_coffee_beans"));
    public static final RegistryObject<Item> KONA_COFFEE_BEANS = ITEMS.register("kona_coffee_beans", () -> new DDItemBase("kona_coffee_beans"));

    public static final RegistryObject<Item> COFFEE_CUP = ITEMS.register("coffee_cup", () -> new DDDrinkBase("coffee_cup", 3, 2.4F));
    public static final RegistryObject<Item> MOCHA_COFFEE_CUP = ITEMS.register("mocha_coffee_cup", () -> new DDDrinkBase("mocha_coffee_cup", 3, 2.4F));
    public static final RegistryObject<Item> ESPRESSO_COFFEE_CUP = ITEMS.register("espresso_coffee_cup", () -> new DDDrinkBase("espresso_coffee_cup", 3, 2.4F, true, 1200, 3));
    public static final RegistryObject<Item> CAPPUCCINO_COFFEE_CUP = ITEMS.register("cappuccino_coffee_cup", () -> new DDDrinkBase("cappuccino_coffee_cup", 3, 2.4F));
    public static final RegistryObject<Item> LATTE_COFFEE_CUP = ITEMS.register("latte_coffee_cup", () -> new DDDrinkBase("latte_coffee_cup", 3, 2.4F));
    public static final RegistryObject<Item> MACCHIATO_COFFEE_CUP = ITEMS.register("macchiato_coffee_cup", () -> new DDDrinkBase("macchiato_coffee_cup", 3, 2.4F));
    public static final RegistryObject<Item> COLD_BREW_COFFEE_CUP = ITEMS.register("cold_brew_coffee_cup", () -> new DDDrinkBase("cold_brew_coffee_cup", 3, 2.4F));
    public static final RegistryObject<Item> AMERICAN_COFFEE_CUP = ITEMS.register("american_coffee_cup", () -> new DDDrinkBase("american_coffee_cup", 3, 2.4F));
    public static final RegistryObject<Item> KONA_COFFEE_CUP = ITEMS.register("kona_coffee_cup", () -> new DDDrinkBase("kona_coffee_cup", 3, 2.4F));

    // ========== 茶叶相关 ==========
    public static final RegistryObject<Item> FRESH_TEA_BRANCH = ITEMS.register("fresh_tea_branch", () -> new DDItemBase("fresh_tea_branch"));
    public static final RegistryObject<Item> FRESH_TEA = ITEMS.register("fresh_tea", () -> new DDItemBase("fresh_tea"));
    public static final RegistryObject<Item> GREEN_TEA = ITEMS.register("green_tea", () -> new DDItemBase("green_tea"));
    public static final RegistryObject<Item> MATCHA_TEA = ITEMS.register("matcha_tea", () -> new DDItemBase("matcha_tea"));
    public static final RegistryObject<Item> DRIED_TEA = ITEMS.register("dried_tea", () -> new DDItemBase("dried_tea"));
    public static final RegistryObject<Item> YELLOW_TEA = ITEMS.register("yellow_tea", () -> new DDItemBase("yellow_tea"));
    public static final RegistryObject<Item> WHITE_TEA = ITEMS.register("white_tea", () -> new DDItemBase("white_tea"));
    public static final RegistryObject<Item> OOLONG_TEA = ITEMS.register("oolong_tea", () -> new DDItemBase("oolong_tea"));

    public static final RegistryObject<Item> GREEN_TEA_BAG = ITEMS.register("green_tea_bag", () -> new DDItemBase("green_tea_bag"));
    public static final RegistryObject<Item> MATCHA_TEA_POWDER = ITEMS.register("matcha_tea_powder", () -> new DDItemBase("matcha_tea_powder"));
    public static final RegistryObject<Item> BLACK_TEA_BAG = ITEMS.register("black_tea_bag", () -> new DDItemBase("black_tea_bag"));
    public static final RegistryObject<Item> YELLOW_TEA_BAG = ITEMS.register("yellow_tea_bag", () -> new DDItemBase("yellow_tea_bag"));
    public static final RegistryObject<Item> WHITE_TEA_BAG = ITEMS.register("white_tea_bag", () -> new DDItemBase("white_tea_bag"));
    public static final RegistryObject<Item> OOLONG_TEA_BAG = ITEMS.register("oolong_tea_bag", () -> new DDItemBase("oolong_tea_bag"));

    public static final RegistryObject<Item> TEA_CUP = ITEMS.register("tea_cup", () -> new DDDrinkBase("tea_cup", 3, 2.4F, 16));
    public static final RegistryObject<Item> GREEN_TEA_CUP = ITEMS.register("green_tea_cup", () -> new DDDrinkBase("green_tea_cup", 3, 2.4F, 16));
    public static final RegistryObject<Item> MATCHA_TEA_CUP = ITEMS.register("matcha_tea_cup", () -> new DDDrinkBase("matcha_tea_cup", 3, 2.4F, 16));
    public static final RegistryObject<Item> BLACK_TEA_CUP = ITEMS.register("black_tea_cup", () -> new DDDrinkBase("black_tea_cup", 3, 2.4F, 16));
    public static final RegistryObject<Item> YELLOW_TEA_CUP = ITEMS.register("yellow_tea_cup", () -> new DDDrinkBase("yellow_tea_cup", 3, 2.4F, 16));
    public static final RegistryObject<Item> WHITE_TEA_CUP = ITEMS.register("white_tea_cup", () -> new DDDrinkBase("white_tea_cup", 3, 2.4F, 16));
    public static final RegistryObject<Item> OOLONG_TEA_CUP = ITEMS.register("oolong_tea_cup", () -> new DDDrinkBase("oolong_tea_cup", 3, 2.4F, 16));
    public static final RegistryObject<Item> BOBA_TEA_GLASS = ITEMS.register("boba_tea_glass", () -> new DDDrinkBase("boba_tea_glass", 4, 2.4F, true));

    // ========== 巧克力相关 ==========
    public static final RegistryObject<Item> CHOCOLATE_BAR = ITEMS.register("chocolate_bar", () -> new DDFoodBase("chocolate_bar", 3, 0.4F));
    public static final RegistryObject<Item> WHITE_CHOCOLATE_BAR = ITEMS.register("white_chocolate_bar", () -> new DDFoodBase("white_chocolate_bar", 3, 0.4F));
    public static final RegistryObject<Item> DARK_CHOCOLATE_BAR = ITEMS.register("dark_chocolate_bar", () -> new DDFoodBase("dark_chocolate_bar", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_CHIPS = ITEMS.register("chocolate_chips", () -> new DDFoodBase("chocolate_chips", 1, 0.2F));
    public static final RegistryObject<Item> WHITE_CHOCOLATE_CHIPS = ITEMS.register("white_chocolate_chips", () -> new DDFoodBase("white_chocolate_chips", 1, 0.2F));

    // ========== 水果 ==========
    public static final RegistryObject<Item> CHERRY = ITEMS.register("cherry", () -> new DDFoodBase("cherry", 2, 0.6F));
    public static final RegistryObject<Item> BLUEBERRY = ITEMS.register("blueberry", () -> new DDFoodBase("blueberry", 2, 0.6F));
    public static final RegistryObject<Item> BLACKBERRY = ITEMS.register("blackberry", () -> new DDFoodBase("blackberry", 2, 0.6F));
    public static final RegistryObject<Item> STRAWBERRY = ITEMS.register("strawberry", () -> new DDFoodBase("strawberry", 2, 2.4F));
    public static final RegistryObject<Item> ORANGE_POPSICLE = ITEMS.register("orange_popsicle", () -> new DDFoodBase("orange_popsicle", 1, 0.2F));
    public static final RegistryObject<Item> ORANGE_MACARON = ITEMS.register("orange_macaron", () -> new DDFoodBase("orange_macaron", 3, 0.4F));
    public static final RegistryObject<Item> ORANGE_LOLLIPOP = ITEMS.register("orange_lollipop", () -> new DDCandyBase("orange_lollipop", 1, 0.2F, 8));
    public static final RegistryObject<Item> ORANGE_JAMMIE_DODGER = ITEMS.register("orange_jammie_dodger", () -> new DDFoodBase("orange_jammie_dodger", 3, 0.4F));
    public static final RegistryObject<Item> ORANGE_CANDYCANE = ITEMS.register("orange_candycane", () -> new DDCandyBase("orange_candycane", 1, 0.4F, 15));
    public static final RegistryObject<Item> ORANGE_GUMMY_BEAR = ITEMS.register("orange_gummy_bear", () -> new DDCandyBase("orange_gummy_bear", 1, 0.2F, 12));
    public static final RegistryObject<Item> ORANGE_JELLO = ITEMS.register("orange_jello", () -> new DDCandyBase("orange_jello", 1, 0.2F, 12));
    public static final RegistryObject<Item> ORANGE_JELLYBEAN = ITEMS.register("orange_jellybean", () -> new DDCandyBase("orange_jellybean", 1, 0.2F, 8));
    public static final RegistryObject<Item> ORANGE_JOLLY_RANCHER = ITEMS.register("orange_jolly_rancher", () -> new DDCandyBase("orange_jolly_rancher", 1, 0.4F, 15));
    public static final RegistryObject<Item> ORANGE_TAFFY = ITEMS.register("orange_taffy", () -> new DDCandyBase("orange_taffy", 1, 0.3F, 10));

    // ========== 原料 ==========
    public static final RegistryObject<Item> GINGER = ITEMS.register("ginger", () -> new DDItemBase("ginger"));
    public static final RegistryObject<Item> MINT = ITEMS.register("mint", () -> new DDItemBase("mint"));
    public static final RegistryObject<Item> VANILLA = ITEMS.register("vanilla", () -> new DDItemBase("vanilla"));
    public static final RegistryObject<Item> RICE = ITEMS.register("rice", () -> new DDFoodBase("rice", 1, 0.2F));
    public static final RegistryObject<Item> FLOUR = ITEMS.register("flour", () -> new DDItemBase("flour"));
    public static final RegistryObject<Item> RICE_FLOUR = ITEMS.register("rice_flour", () -> new DDItemBase("rice_flour"));
    public static final RegistryObject<Item> POTATO_STARCH = ITEMS.register("potato_starch", () -> new DDItemBase("potato_starch"));
    public static final RegistryObject<Item> DOUGH = ITEMS.register("dough", () -> new DDItemBase("dough"));
    public static final RegistryObject<Item> GLUTEN_FREE_DOUGH = ITEMS.register("gluten_free_dough", () -> new DDItemBase("gluten_free_dough"));
    public static final RegistryObject<Item> CROISSANT_DOUGH = ITEMS.register("croissant_dough", () -> new DDFoodBase("croissant_dough", 1, 0.2F));
    public static final RegistryObject<Item> PRETZEL_DOUGH = ITEMS.register("pretzel_dough", () -> new DDItemBase("pretzel_dough"));
    public static final RegistryObject<Item> GLUTEN_FREE_PRETZEL_DOUGH = ITEMS.register("gluten_free_pretzel_dough", () -> new DDItemBase("gluten_free_pretzel_dough"));
    public static final RegistryObject<Item> CARAMEL = ITEMS.register("caramel", () -> new DDFoodBase("caramel", 1, 0.1F));
    public static final RegistryObject<Item> BUTTER = ITEMS.register("butter", () -> new DDFoodBase("butter", 1, 0.1F));
    public static final RegistryObject<Item> CHEESE = ITEMS.register("cheese", () -> new DDFoodBase("cheese", 2, 0.1F));
    public static final RegistryObject<Item> CREAM = ITEMS.register("cream", () -> new DDItemBase("cream"));
    public static final RegistryObject<Item> GELATIN = ITEMS.register("gelatin", () -> new DDItemBase("gelatin"));
    public static final RegistryObject<Item> MARSHMALLOW = ITEMS.register("marshmallow", () -> new DDFoodBase("marshmallow", 1, 0.2F));
    public static final RegistryObject<Item> PECAN = ITEMS.register("pecan", () -> new DDFoodBase("pecan", 1, 0.2F));
    public static final RegistryObject<Item> PEANUT_BUTTER = ITEMS.register("peanut_butter", () -> new DDItemBase("peanut_butter"));
    // COCONUT 已删除，使用 pamhc2trees:coconutitem 代替
    public static final RegistryObject<Item> COCONUT_SHAVINGS = ITEMS.register("coconut_shavings", () -> new DDItemBase("coconut_shavings"));
    public static final RegistryObject<Item> ANISE = ITEMS.register("anise", () -> new DDItemBase("anise"));
    public static final RegistryObject<Item> BOILED_SUGAR = ITEMS.register("boiled_sugar", () -> new DDItemBase("boiled_sugar"));
    public static final RegistryObject<Item> BOILING_WATER_BUCKET = ITEMS.register("boiling_water_bucket", () -> new DDItemBase("boiling_water_bucket"));

    // ========== 种子 (使用延迟引用避免循环依赖) ==========
    public static final RegistryObject<Item> TEA_SEEDS = ITEMS.register("tea_seeds", () -> new DDSeedItem("tea_seeds", () -> DDBlockInit.TEA_CROP.get()));
    public static final RegistryObject<Item> STRAWBERRY_SEEDS = ITEMS.register("strawberry_seeds", () -> new DDSeedItem("strawberry_seeds", () -> DDBlockInit.STRAWBERRY_CROP.get()));
    public static final RegistryObject<Item> MINT_SEEDS = ITEMS.register("mint_seeds", () -> new DDSeedItem("mint_seeds", () -> DDBlockInit.MINT_CROP.get()));
    public static final RegistryObject<Item> RICE_SEEDS = ITEMS.register("rice_seeds", () -> new DDSeedItem("rice_seeds", () -> DDBlockInit.RICE_CROP.get()));
    public static final RegistryObject<Item> BLUEBERRY_SEEDS = ITEMS.register("blueberry_seeds", () -> new DDSeedItem("blueberry_seeds", () -> DDBlockInit.BLUEBERRY_CROP.get()));
    public static final RegistryObject<Item> CHERRY_SEEDS = ITEMS.register("cherry_seeds", () -> new DDSeedItem("cherry_seeds", () -> DDBlockInit.CHERRY_CROP.get()));
    public static final RegistryObject<Item> GINGER_SEEDS = ITEMS.register("ginger_seeds", () -> new DDSeedItem("ginger_seeds", () -> DDBlockInit.GINGER_CROP.get()));
    public static final RegistryObject<Item> BLACKBERRY_SEEDS = ITEMS.register("blackberry_seeds", () -> new DDSeedItem("blackberry_seeds", () -> DDBlockInit.BLACKBERRY_CROP.get()));
    public static final RegistryObject<Item> ANISE_SEEDS = ITEMS.register("anise_seeds", () -> new DDSeedItem("anise_seeds", () -> DDBlockInit.ANISE_CROP.get()));

    // ========== 蛋糕基底 ==========
    public static final RegistryObject<Item> VANILLA_CAKE_BASE = ITEMS.register("vanilla_cake_base", () -> new DDItemBase("vanilla_cake_base"));
    public static final RegistryObject<Item> CHOCOLATE_CAKE_BASE = ITEMS.register("chocolate_cake_base", () -> new DDItemBase("chocolate_cake_base"));
    public static final RegistryObject<Item> RED_VELVET_CAKE_BASE = ITEMS.register("red_velvet_cake_base", () -> new DDItemBase("red_velvet_cake_base"));

    // ========== 蛋糕切片 ==========
    public static final RegistryObject<Item> VANILLA_FROSTED_VANILLA_CAKE_SLICE = ITEMS.register("vanilla_frosted_vanilla_cake_slice", () -> new DDFoodBase("vanilla_frosted_vanilla_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_VANILLA_CAKE_SLICE = ITEMS.register("chocolate_frosted_vanilla_cake_slice", () -> new DDFoodBase("chocolate_frosted_vanilla_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_VANILLA_CAKE_SLICE = ITEMS.register("strawberry_frosted_vanilla_cake_slice", () -> new DDFoodBase("strawberry_frosted_vanilla_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> VANILLA_FROSTED_CHOCOLATE_CAKE_SLICE = ITEMS.register("vanilla_frosted_chocolate_cake_slice", () -> new DDFoodBase("vanilla_frosted_chocolate_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_CHOCOLATE_CAKE_SLICE = ITEMS.register("chocolate_frosted_chocolate_cake_slice", () -> new DDFoodBase("chocolate_frosted_chocolate_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_CHOCOLATE_CAKE_SLICE = ITEMS.register("strawberry_frosted_chocolate_cake_slice", () -> new DDFoodBase("strawberry_frosted_chocolate_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> MINT_FROSTED_CHOCOLATE_CAKE_SLICE = ITEMS.register("mint_frosted_chocolate_cake_slice", () -> new DDFoodBase("mint_frosted_chocolate_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_MOUSSE_CAKE_SLICE = ITEMS.register("chocolate_mousse_cake_slice", () -> new DDFoodBase("chocolate_mousse_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> VANILLA_CHEESE_CAKE_SLICE = ITEMS.register("vanilla_cheese_cake_slice", () -> new DDFoodBase("vanilla_cheese_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_CHEESE_CAKE_SLICE = ITEMS.register("chocolate_cheese_cake_slice", () -> new DDFoodBase("chocolate_cheese_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> COFFEE_CAKE_SLICE = ITEMS.register("coffee_cake_slice", () -> new DDFoodBase("coffee_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> VANILLA_RED_VELVET_CAKE_SLICE = ITEMS.register("vanilla_red_velvet_cake_slice", () -> new DDFoodBase("vanilla_red_velvet_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_RED_VELVET_CAKE_SLICE = ITEMS.register("chocolate_red_velvet_cake_slice", () -> new DDFoodBase("chocolate_red_velvet_cake_slice", 2, 0.4F));
    public static final RegistryObject<Item> SPONGE_CAKE_SLICE = ITEMS.register("sponge_cake_slice", () -> new DDFoodBase("sponge_cake_slice", 2, 0.4F));

    // ========== 纸杯蛋糕 ==========
    public static final RegistryObject<Item> VANILLA_CUPCAKE_BASE = ITEMS.register("vanilla_cupcake_base", () -> new DDFoodBase("vanilla_cupcake_base", 5, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_CUPCAKE_BASE = ITEMS.register("chocolate_cupcake_base", () -> new DDFoodBase("chocolate_cupcake_base", 5, 0.8F));
    public static final RegistryObject<Item> RED_VELVET_CUPCAKE_BASE = ITEMS.register("red_velvet_cupcake_base", () -> new DDFoodBase("red_velvet_cupcake_base", 5, 0.8F));

    // ========== 纸杯蛋糕面团 ==========
    public static final RegistryObject<Item> VANILLA_CUPCAKE_DOUGH = ITEMS.register("vanilla_cupcake_dough", () -> new DDFoodBase("vanilla_cupcake_dough", 1, 0.2F));
    public static final RegistryObject<Item> CHOCOLATE_CUPCAKE_DOUGH = ITEMS.register("chocolate_cupcake_dough", () -> new DDFoodBase("chocolate_cupcake_dough", 1, 0.2F));
    public static final RegistryObject<Item> RED_VELVET_CUPCAKE_DOUGH = ITEMS.register("red_velvet_cupcake_dough", () -> new DDFoodBase("red_velvet_cupcake_dough", 1, 0.2F));

    // ========== 烤盘 ==========
    public static final RegistryObject<Item> VANILLA_CUPCAKE_TRAY = ITEMS.register("vanilla_cupcake_tray", () -> new DDItemBase("vanilla_cupcake_tray"));
    public static final RegistryObject<Item> CHOCOLATE_CUPCAKE_TRAY = ITEMS.register("chocolate_cupcake_tray", () -> new DDItemBase("chocolate_cupcake_tray"));
    public static final RegistryObject<Item> RED_VELVET_CUPCAKE_TRAY = ITEMS.register("red_velvet_cupcake_tray", () -> new DDItemBase("red_velvet_cupcake_tray"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_TRAY = ITEMS.register("vanilla_muffin_tray", () -> new DDItemBase("vanilla_muffin_tray"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_TRAY_BLUEBERRY = ITEMS.register("vanilla_muffin_tray_blueberry", () -> new DDItemBase("vanilla_muffin_tray_blueberry"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_TRAY_CHOCOLATE_CHIP = ITEMS.register("vanilla_muffin_tray_chocolate_chip", () -> new DDItemBase("vanilla_muffin_tray_chocolate_chip"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_TRAY_STRAWBERRY = ITEMS.register("vanilla_muffin_tray_strawberry", () -> new DDItemBase("vanilla_muffin_tray_strawberry"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_TRAY_POPPY_SEED = ITEMS.register("vanilla_muffin_tray_poppy_seed", () -> new DDItemBase("vanilla_muffin_tray_poppy_seed"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_TRAY_BLACKBERRY = ITEMS.register("vanilla_muffin_tray_blackberry", () -> new DDItemBase("vanilla_muffin_tray_blackberry"));
    public static final RegistryObject<Item> BANANA_BREAD_MUFFIN_TRAY = ITEMS.register("banana_bread_muffin_tray", () -> new DDItemBase("banana_bread_muffin_tray"));
    public static final RegistryObject<Item> BANANA_BREAD_MUFFIN_TRAY_CHOCOLATE = ITEMS.register("banana_bread_muffin_tray_chocolate", () -> new DDItemBase("banana_bread_muffin_tray_chocolate"));

    public static final RegistryObject<Item> VANILLA_FROSTED_VANILLA_CUPCAKE = ITEMS.register("vanilla_frosted_vanilla_cupcake", () -> new DDFoodBase("vanilla_frosted_vanilla_cupcake", 6, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_VANILLA_CUPCAKE = ITEMS.register("chocolate_frosted_vanilla_cupcake", () -> new DDFoodBase("chocolate_frosted_vanilla_cupcake", 6, 0.8F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_VANILLA_CUPCAKE = ITEMS.register("strawberry_frosted_vanilla_cupcake", () -> new DDFoodBase("strawberry_frosted_vanilla_cupcake", 6, 0.8F));
    public static final RegistryObject<Item> VANILLA_FROSTED_VANILLA_CUPCAKE_SPRINKLES = ITEMS.register("vanilla_frosted_vanilla_cupcake_sprinkles", () -> new DDFoodBase("vanilla_frosted_vanilla_cupcake_sprinkles", 6, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_VANILLA_CUPCAKE_SPRINKLES = ITEMS.register("chocolate_frosted_vanilla_cupcake_sprinkles", () -> new DDFoodBase("chocolate_frosted_vanilla_cupcake_sprinkles", 6, 0.8F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_VANILLA_CUPCAKE_SPRINKLES = ITEMS.register("strawberry_frosted_vanilla_cupcake_sprinkles", () -> new DDFoodBase("strawberry_frosted_vanilla_cupcake_sprinkles", 6, 0.8F));
    public static final RegistryObject<Item> VANILLA_FROSTED_CHOCOLATE_CUPCAKE = ITEMS.register("vanilla_frosted_chocolate_cupcake", () -> new DDFoodBase("vanilla_frosted_chocolate_cupcake", 6, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_CHOCOLATE_CUPCAKE = ITEMS.register("chocolate_frosted_chocolate_cupcake", () -> new DDFoodBase("chocolate_frosted_chocolate_cupcake", 6, 0.8F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_CHOCOLATE_CUPCAKE = ITEMS.register("strawberry_frosted_chocolate_cupcake", () -> new DDFoodBase("strawberry_frosted_chocolate_cupcake", 6, 0.8F));
    public static final RegistryObject<Item> MINT_FROSTED_CHOCOLATE_CUPCAKE = ITEMS.register("mint_frosted_chocolate_cupcake", () -> new DDFoodBase("mint_frosted_chocolate_cupcake", 6, 0.8F));
    public static final RegistryObject<Item> VANILLA_FROSTED_CHOCOLATE_CUPCAKE_SPRINKLES = ITEMS.register("vanilla_frosted_chocolate_cupcake_sprinkles", () -> new DDFoodBase("vanilla_frosted_chocolate_cupcake_sprinkles", 6, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_CHOCOLATE_CUPCAKE_SPRINKLES = ITEMS.register("chocolate_frosted_chocolate_cupcake_sprinkles", () -> new DDFoodBase("chocolate_frosted_chocolate_cupcake_sprinkles", 6, 0.8F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_CHOCOLATE_CUPCAKE_SPRINKLES = ITEMS.register("strawberry_frosted_chocolate_cupcake_sprinkles", () -> new DDFoodBase("strawberry_frosted_chocolate_cupcake_sprinkles", 6, 0.8F));
    public static final RegistryObject<Item> VANILLA_RED_VELVET_CUPCAKE = ITEMS.register("vanilla_red_velvet_cupcake", () -> new DDFoodBase("vanilla_red_velvet_cupcake", 6, 0.8F));
    public static final RegistryObject<Item> VANILLA_RED_VELVET_CUPCAKE_SPRINKLES = ITEMS.register("vanilla_red_velvet_cupcake_sprinkles", () -> new DDFoodBase("vanilla_red_velvet_cupcake_sprinkles", 6, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_RED_VELVET_CUPCAKE = ITEMS.register("chocolate_red_velvet_cupcake", () -> new DDFoodBase("chocolate_red_velvet_cupcake", 6, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_RED_VELVET_CUPCAKE_SPRINKLES = ITEMS.register("chocolate_red_velvet_cupcake_sprinkles", () -> new DDFoodBase("chocolate_red_velvet_cupcake_sprinkles", 6, 0.8F));

    // ========== 蛋糕棒 ==========
    public static final RegistryObject<Item> VANILLA_CAKE_POP = ITEMS.register("vanilla_cake_pop", () -> new DDFoodBase("vanilla_cake_pop", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_CAKE_POP = ITEMS.register("chocolate_cake_pop", () -> new DDFoodBase("chocolate_cake_pop", 3, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_CAKE_POP = ITEMS.register("strawberry_cake_pop", () -> new DDFoodBase("strawberry_cake_pop", 3, 0.4F));
    public static final RegistryObject<Item> MINT_CAKE_POP = ITEMS.register("mint_cake_pop", () -> new DDFoodBase("mint_cake_pop", 3, 0.4F));
    public static final RegistryObject<Item> RED_VELVET_CAKE_POP = ITEMS.register("red_velvet_cake_pop", () -> new DDFoodBase("red_velvet_cake_pop", 3, 0.4F, "allypoo2001"));

    // ========== 冰淇淋 ==========
    public static final RegistryObject<Item> VANILLA_ICE_CREAM = ITEMS.register("vanilla_ice_cream", () -> new DDFoodBase("vanilla_ice_cream", 6, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM = ITEMS.register("chocolate_ice_cream", () -> new DDFoodBase("chocolate_ice_cream", 6, 1.8F));
    public static final RegistryObject<Item> STRAWBERRY_ICE_CREAM = ITEMS.register("strawberry_ice_cream", () -> new DDFoodBase("strawberry_ice_cream", 6, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM = ITEMS.register("mint_ice_cream", () -> new DDFoodBase("mint_ice_cream", 6, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM = ITEMS.register("neapolitan_ice_cream", () -> new DDFoodBase("neapolitan_ice_cream", 6, 1.8F));
    public static final RegistryObject<Item> VANILLA_CHOCOLATE_CHIP_ICE_CREAM = ITEMS.register("vanilla_chocolate_chip_ice_cream", () -> new DDFoodBase("vanilla_chocolate_chip_ice_cream", 6, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_CHOCOLATE_CHIP_ICE_CREAM = ITEMS.register("chocolate_chocolate_chip_ice_cream", () -> new DDFoodBase("chocolate_chocolate_chip_ice_cream", 6, 1.8F));
    public static final RegistryObject<Item> STRAWBERRY_CHOCOLATE_CHIP_ICE_CREAM = ITEMS.register("strawberry_chocolate_chip_ice_cream", () -> new DDFoodBase("strawberry_chocolate_chip_ice_cream", 6, 1.8F));
    public static final RegistryObject<Item> MINT_CHOCOLATE_CHIP_ICE_CREAM = ITEMS.register("mint_chocolate_chip_ice_cream", () -> new DDFoodBase("mint_chocolate_chip_ice_cream", 6, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_CHOCOLATE_CHIP_ICE_CREAM = ITEMS.register("neapolitan_chocolate_chip_ice_cream", () -> new DDFoodBase("neapolitan_chocolate_chip_ice_cream", 6, 1.8F));

    // 冰淇淋阶段变体（2-6个球）
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_SPRINKLES = ITEMS.register("vanilla_ice_cream_sprinkles", () -> new DDFoodBase("vanilla_ice_cream_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_SPRINKLES = ITEMS.register("chocolate_ice_cream_sprinkles", () -> new DDFoodBase("chocolate_ice_cream_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> STRAWBERRY_ICE_CREAM_SPRINKLES = ITEMS.register("strawberry_ice_cream_sprinkles", () -> new DDFoodBase("strawberry_ice_cream_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_SPRINKLES = ITEMS.register("mint_ice_cream_sprinkles", () -> new DDFoodBase("mint_ice_cream_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_SPRINKLES = ITEMS.register("neapolitan_ice_cream_sprinkles", () -> new DDFoodBase("neapolitan_ice_cream_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_CHOCOLATE_SYRUP = ITEMS.register("vanilla_ice_cream_chocolate_syrup", () -> new DDFoodBase("vanilla_ice_cream_chocolate_syrup", 6, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_CHOCOLATE_SYRUP = ITEMS.register("chocolate_ice_cream_chocolate_syrup", () -> new DDFoodBase("chocolate_ice_cream_chocolate_syrup", 6, 1.8F));
    public static final RegistryObject<Item> STRAWBERRY_ICE_CREAM_CHOCOLATE_SYRUP = ITEMS.register("strawberry_ice_cream_chocolate_syrup", () -> new DDFoodBase("strawberry_ice_cream_chocolate_syrup", 6, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_CHOCOLATE_SYRUP = ITEMS.register("mint_ice_cream_chocolate_syrup", () -> new DDFoodBase("mint_ice_cream_chocolate_syrup", 6, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_CHOCOLATE_SYRUP = ITEMS.register("neapolitan_ice_cream_chocolate_syrup", () -> new DDFoodBase("neapolitan_ice_cream_chocolate_syrup", 6, 1.8F));
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("vanilla_ice_cream_chocolate_syrup_sprinkles", () -> new DDFoodBase("vanilla_ice_cream_chocolate_syrup_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("chocolate_ice_cream_chocolate_syrup_sprinkles", () -> new DDFoodBase("chocolate_ice_cream_chocolate_syrup_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> STRAWBERRY_ICE_CREAM_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("strawberry_ice_cream_chocolate_syrup_sprinkles", () -> new DDFoodBase("strawberry_ice_cream_chocolate_syrup_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("mint_ice_cream_chocolate_syrup_sprinkles", () -> new DDFoodBase("mint_ice_cream_chocolate_syrup_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("neapolitan_ice_cream_chocolate_syrup_sprinkles", () -> new DDFoodBase("neapolitan_ice_cream_chocolate_syrup_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_STRAWBERRY_SYRUP = ITEMS.register("vanilla_ice_cream_strawberry_syrup", () -> new DDFoodBase("vanilla_ice_cream_strawberry_syrup", 6, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_STRAWBERRY_SYRUP = ITEMS.register("chocolate_ice_cream_strawberry_syrup", () -> new DDFoodBase("chocolate_ice_cream_strawberry_syrup", 6, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_STRAWBERRY_SYRUP = ITEMS.register("mint_ice_cream_strawberry_syrup", () -> new DDFoodBase("mint_ice_cream_strawberry_syrup", 6, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_STRAWBERRY_SYRUP = ITEMS.register("neapolitan_ice_cream_strawberry_syrup", () -> new DDFoodBase("neapolitan_ice_cream_strawberry_syrup", 6, 1.8F));
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("vanilla_ice_cream_strawberry_syrup_sprinkles", () -> new DDFoodBase("vanilla_ice_cream_strawberry_syrup_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("chocolate_ice_cream_strawberry_syrup_sprinkles", () -> new DDFoodBase("chocolate_ice_cream_strawberry_syrup_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("mint_ice_cream_strawberry_syrup_sprinkles", () -> new DDFoodBase("mint_ice_cream_strawberry_syrup_sprinkles", 6, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("neapolitan_ice_cream_strawberry_syrup_sprinkles", () -> new DDFoodBase("neapolitan_ice_cream_strawberry_syrup_sprinkles", 6, 1.8F));

    public static final RegistryObject<Item> ICE_CREAM_CONE = ITEMS.register("ice_cream_cone", () -> new DDFoodBase("ice_cream_cone", 2, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_WAFFLE_CONE = ITEMS.register("chocolate_waffle_cone", () -> new DDFoodBase("chocolate_waffle_cone", 2, 0.4F));
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_CONE = ITEMS.register("vanilla_ice_cream_cone", () -> new DDFoodBase("vanilla_ice_cream_cone", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_CONE = ITEMS.register("chocolate_ice_cream_cone", () -> new DDFoodBase("chocolate_ice_cream_cone", 7, 1.8F));
    public static final RegistryObject<Item> STRAWBERRY_ICE_CREAM_CONE = ITEMS.register("strawberry_ice_cream_cone", () -> new DDFoodBase("strawberry_ice_cream_cone", 7, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_CONE = ITEMS.register("mint_ice_cream_cone", () -> new DDFoodBase("mint_ice_cream_cone", 7, 1.8F));
    public static final RegistryObject<Item> MINT_CHOCOLATE_CHIP_ICE_CREAM_CONE = ITEMS.register("mint_chocolate_chip_ice_cream_cone", () -> new DDFoodBase("mint_chocolate_chip_ice_cream_cone", 7, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_CONE = ITEMS.register("neapolitan_ice_cream_cone", () -> new DDFoodBase("neapolitan_ice_cream_cone", 7, 1.8F));

    // 冰淇淋蛋筒阶段变体（2-6个球）
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_CONE_SPRINKLES = ITEMS.register("vanilla_ice_cream_cone_sprinkles", () -> new DDFoodBase("vanilla_ice_cream_cone_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_CONE_SPRINKLES = ITEMS.register("chocolate_ice_cream_cone_sprinkles", () -> new DDFoodBase("chocolate_ice_cream_cone_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> STRAWBERRY_ICE_CREAM_CONE_SPRINKLES = ITEMS.register("strawberry_ice_cream_cone_sprinkles", () -> new DDFoodBase("strawberry_ice_cream_cone_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_CONE_SPRINKLES = ITEMS.register("mint_ice_cream_cone_sprinkles", () -> new DDFoodBase("mint_ice_cream_cone_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_CONE_SPRINKLES = ITEMS.register("neapolitan_ice_cream_cone_sprinkles", () -> new DDFoodBase("neapolitan_ice_cream_cone_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_CONE_CHOCOLATE_SYRUP = ITEMS.register("vanilla_ice_cream_cone_chocolate_syrup", () -> new DDFoodBase("vanilla_ice_cream_cone_chocolate_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_CONE_CHOCOLATE_SYRUP = ITEMS.register("chocolate_ice_cream_cone_chocolate_syrup", () -> new DDFoodBase("chocolate_ice_cream_cone_chocolate_syrup", 7, 1.8F));
    public static final RegistryObject<Item> STRAWBERRY_ICE_CREAM_CONE_CHOCOLATE_SYRUP = ITEMS.register("strawberry_ice_cream_cone_chocolate_syrup", () -> new DDFoodBase("strawberry_ice_cream_cone_chocolate_syrup", 7, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_CONE_CHOCOLATE_SYRUP = ITEMS.register("mint_ice_cream_cone_chocolate_syrup", () -> new DDFoodBase("mint_ice_cream_cone_chocolate_syrup", 7, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_CONE_CHOCOLATE_SYRUP = ITEMS.register("neapolitan_ice_cream_cone_chocolate_syrup", () -> new DDFoodBase("neapolitan_ice_cream_cone_chocolate_syrup", 7, 1.8F));
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_CONE_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("vanilla_ice_cream_cone_chocolate_syrup_sprinkles", () -> new DDFoodBase("vanilla_ice_cream_cone_chocolate_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_CONE_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("chocolate_ice_cream_cone_chocolate_syrup_sprinkles", () -> new DDFoodBase("chocolate_ice_cream_cone_chocolate_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> STRAWBERRY_ICE_CREAM_CONE_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("strawberry_ice_cream_cone_chocolate_syrup_sprinkles", () -> new DDFoodBase("strawberry_ice_cream_cone_chocolate_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_CONE_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("mint_ice_cream_cone_chocolate_syrup_sprinkles", () -> new DDFoodBase("mint_ice_cream_cone_chocolate_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_CONE_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("neapolitan_ice_cream_cone_chocolate_syrup_sprinkles", () -> new DDFoodBase("neapolitan_ice_cream_cone_chocolate_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_CONE_STRAWBERRY_SYRUP = ITEMS.register("vanilla_ice_cream_cone_strawberry_syrup", () -> new DDFoodBase("vanilla_ice_cream_cone_strawberry_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_CONE_STRAWBERRY_SYRUP = ITEMS.register("chocolate_ice_cream_cone_strawberry_syrup", () -> new DDFoodBase("chocolate_ice_cream_cone_strawberry_syrup", 7, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_CONE_STRAWBERRY_SYRUP = ITEMS.register("mint_ice_cream_cone_strawberry_syrup", () -> new DDFoodBase("mint_ice_cream_cone_strawberry_syrup", 7, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_CONE_STRAWBERRY_SYRUP = ITEMS.register("neapolitan_ice_cream_cone_strawberry_syrup", () -> new DDFoodBase("neapolitan_ice_cream_cone_strawberry_syrup", 7, 1.8F));
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_CONE_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("vanilla_ice_cream_cone_strawberry_syrup_sprinkles", () -> new DDFoodBase("vanilla_ice_cream_cone_strawberry_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_CONE_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("chocolate_ice_cream_cone_strawberry_syrup_sprinkles", () -> new DDFoodBase("chocolate_ice_cream_cone_strawberry_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_CONE_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("mint_ice_cream_cone_strawberry_syrup_sprinkles", () -> new DDFoodBase("mint_ice_cream_cone_strawberry_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_CONE_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("neapolitan_ice_cream_cone_strawberry_syrup_sprinkles", () -> new DDFoodBase("neapolitan_ice_cream_cone_strawberry_syrup_sprinkles", 7, 1.8F));

    // 巧克力涂层冰淇淋蛋筒
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_VANILLA_ICE_CREAM_CONE = ITEMS.register("chocolate_dipped_vanilla_ice_cream_cone", () -> new DDFoodBase("chocolate_dipped_vanilla_ice_cream_cone", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_CHOCOLATE_ICE_CREAM_CONE = ITEMS.register("chocolate_dipped_chocolate_ice_cream_cone", () -> new DDFoodBase("chocolate_dipped_chocolate_ice_cream_cone", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_STRAWBERRY_ICE_CREAM_CONE = ITEMS.register("chocolate_dipped_strawberry_ice_cream_cone", () -> new DDFoodBase("chocolate_dipped_strawberry_ice_cream_cone", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_MINT_ICE_CREAM_CONE = ITEMS.register("chocolate_dipped_mint_ice_cream_cone", () -> new DDFoodBase("chocolate_dipped_mint_ice_cream_cone", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_NEAPOLITAN_ICE_CREAM_CONE = ITEMS.register("chocolate_dipped_neapolitan_ice_cream_cone", () -> new DDFoodBase("chocolate_dipped_neapolitan_ice_cream_cone", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_VANILLA_ICE_CREAM_CONE_SPRINKLES = ITEMS.register("chocolate_dipped_vanilla_ice_cream_cone_sprinkles", () -> new DDFoodBase("chocolate_dipped_vanilla_ice_cream_cone_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_CHOCOLATE_ICE_CREAM_CONE_SPRINKLES = ITEMS.register("chocolate_dipped_chocolate_ice_cream_cone_sprinkles", () -> new DDFoodBase("chocolate_dipped_chocolate_ice_cream_cone_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_STRAWBERRY_ICE_CREAM_CONE_SPRINKLES = ITEMS.register("chocolate_dipped_strawberry_ice_cream_cone_sprinkles", () -> new DDFoodBase("chocolate_dipped_strawberry_ice_cream_cone_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_MINT_ICE_CREAM_CONE_SPRINKLES = ITEMS.register("chocolate_dipped_mint_ice_cream_cone_sprinkles", () -> new DDFoodBase("chocolate_dipped_mint_ice_cream_cone_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_NEAPOLITAN_ICE_CREAM_CONE_SPRINKLES = ITEMS.register("chocolate_dipped_neapolitan_ice_cream_cone_sprinkles", () -> new DDFoodBase("chocolate_dipped_neapolitan_ice_cream_cone_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_VANILLA_ICE_CREAM_CONE_CHOCOLATE_SYRUP = ITEMS.register("chocolate_dipped_vanilla_ice_cream_cone_chocolate_syrup", () -> new DDFoodBase("chocolate_dipped_vanilla_ice_cream_cone_chocolate_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_CHOCOLATE_ICE_CREAM_CONE_CHOCOLATE_SYRUP = ITEMS.register("chocolate_dipped_chocolate_ice_cream_cone_chocolate_syrup", () -> new DDFoodBase("chocolate_dipped_chocolate_ice_cream_cone_chocolate_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_STRAWBERRY_ICE_CREAM_CONE_CHOCOLATE_SYRUP = ITEMS.register("chocolate_dipped_strawberry_ice_cream_cone_chocolate_syrup", () -> new DDFoodBase("chocolate_dipped_strawberry_ice_cream_cone_chocolate_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_MINT_ICE_CREAM_CONE_CHOCOLATE_SYRUP = ITEMS.register("chocolate_dipped_mint_ice_cream_cone_chocolate_syrup", () -> new DDFoodBase("chocolate_dipped_mint_ice_cream_cone_chocolate_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_NEAPOLITAN_ICE_CREAM_CONE_CHOCOLATE_SYRUP = ITEMS.register("chocolate_dipped_neapolitan_ice_cream_cone_chocolate_syrup", () -> new DDFoodBase("chocolate_dipped_neapolitan_ice_cream_cone_chocolate_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_VANILLA_ICE_CREAM_CONE_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("chocolate_dipped_vanilla_ice_cream_cone_chocolate_syrup_sprinkles", () -> new DDFoodBase("chocolate_dipped_vanilla_ice_cream_cone_chocolate_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_CHOCOLATE_ICE_CREAM_CONE_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("chocolate_dipped_chocolate_ice_cream_cone_chocolate_syrup_sprinkles", () -> new DDFoodBase("chocolate_dipped_chocolate_ice_cream_cone_chocolate_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_STRAWBERRY_ICE_CREAM_CONE_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("chocolate_dipped_strawberry_ice_cream_cone_chocolate_syrup_sprinkles", () -> new DDFoodBase("chocolate_dipped_strawberry_ice_cream_cone_chocolate_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_MINT_ICE_CREAM_CONE_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("chocolate_dipped_mint_ice_cream_cone_chocolate_syrup_sprinkles", () -> new DDFoodBase("chocolate_dipped_mint_ice_cream_cone_chocolate_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_NEAPOLITAN_ICE_CREAM_CONE_CHOCOLATE_SYRUP_SPRINKLES = ITEMS.register("chocolate_dipped_neapolitan_ice_cream_cone_chocolate_syrup_sprinkles", () -> new DDFoodBase("chocolate_dipped_neapolitan_ice_cream_cone_chocolate_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_VANILLA_ICE_CREAM_CONE_STRAWBERRY_SYRUP = ITEMS.register("chocolate_dipped_vanilla_ice_cream_cone_strawberry_syrup", () -> new DDFoodBase("chocolate_dipped_vanilla_ice_cream_cone_strawberry_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_CHOCOLATE_ICE_CREAM_CONE_STRAWBERRY_SYRUP = ITEMS.register("chocolate_dipped_chocolate_ice_cream_cone_strawberry_syrup", () -> new DDFoodBase("chocolate_dipped_chocolate_ice_cream_cone_strawberry_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_MINT_ICE_CREAM_CONE_STRAWBERRY_SYRUP = ITEMS.register("chocolate_dipped_mint_ice_cream_cone_strawberry_syrup", () -> new DDFoodBase("chocolate_dipped_mint_ice_cream_cone_strawberry_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_NEAPOLITAN_ICE_CREAM_CONE_STRAWBERRY_SYRUP = ITEMS.register("chocolate_dipped_neapolitan_ice_cream_cone_strawberry_syrup", () -> new DDFoodBase("chocolate_dipped_neapolitan_ice_cream_cone_strawberry_syrup", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_VANILLA_ICE_CREAM_CONE_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("chocolate_dipped_vanilla_ice_cream_cone_strawberry_syrup_sprinkles", () -> new DDFoodBase("chocolate_dipped_vanilla_ice_cream_cone_strawberry_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_CHOCOLATE_ICE_CREAM_CONE_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("chocolate_dipped_chocolate_ice_cream_cone_strawberry_syrup_sprinkles", () -> new DDFoodBase("chocolate_dipped_chocolate_ice_cream_cone_strawberry_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_MINT_ICE_CREAM_CONE_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("chocolate_dipped_mint_ice_cream_cone_strawberry_syrup_sprinkles", () -> new DDFoodBase("chocolate_dipped_mint_ice_cream_cone_strawberry_syrup_sprinkles", 7, 1.8F));
    public static final RegistryObject<Item> CHOCOLATE_DIPPED_NEAPOLITAN_ICE_CREAM_CONE_STRAWBERRY_SYRUP_SPRINKLES = ITEMS.register("chocolate_dipped_neapolitan_ice_cream_cone_strawberry_syrup_sprinkles", () -> new DDFoodBase("chocolate_dipped_neapolitan_ice_cream_cone_strawberry_syrup_sprinkles", 7, 1.8F));

    // ========== 奶昔 ==========
    public static final RegistryObject<Item> VANILLA_MILKSHAKE = ITEMS.register("vanilla_milkshake", () -> new DDDrinkBase("vanilla_milkshake", 6, 1.8F, true));
    public static final RegistryObject<Item> CHOCOLATE_MILKSHAKE = ITEMS.register("chocolate_milkshake", () -> new DDDrinkBase("chocolate_milkshake", 6, 1.8F, true));
    public static final RegistryObject<Item> STRAWBERRY_MILKSHAKE = ITEMS.register("strawberry_milkshake", () -> new DDDrinkBase("strawberry_milkshake", 6, 1.8F, true));
    public static final RegistryObject<Item> MINT_MILKSHAKE = ITEMS.register("mint_milkshake", () -> new DDDrinkBase("mint_milkshake", 6, 1.8F, true));
    public static final RegistryObject<Item> MINT_CHOCOLATE_CHIP_MILKSHAKE = ITEMS.register("mint_chocolate_chip_milkshake", () -> new DDDrinkBase("mint_chocolate_chip_milkshake", 6, 1.8F, true));
    public static final RegistryObject<Item> NEAPOLITAN_MILKSHAKE = ITEMS.register("neapolitan_milkshake", () -> new DDDrinkBase("neapolitan_milkshake", 6, 1.8F, true));

    public static final RegistryObject<Item> MILK_GLASS = ITEMS.register("milk_glass", () -> new DDDrinkBase("milk_glass", 2, 0.6F, true));
    public static final RegistryObject<Item> CHOCOLATE_MILK_GLASS = ITEMS.register("chocolate_milk_glass", () -> new DDDrinkBase("chocolate_milk_glass", 3, 0.8F, true));
    public static final RegistryObject<Item> STRAWBERRY_MILK_GLASS = ITEMS.register("strawberry_milk_glass", () -> new DDDrinkBase("strawberry_milk_glass", 3, 0.8F, true));
    public static final RegistryObject<Item> COCONUT_MILK = ITEMS.register("coconut_milk", () -> new DDDrinkBase("coconut_milk", 2, 0.6F, true));

    // ========== 冰棍 ==========
    public static final RegistryObject<Item> CHOCOLATE_POPSICLE = ITEMS.register("chocolate_popsicle", () -> new DDFoodBase("chocolate_popsicle", 1, 0.2F));
    public static final RegistryObject<Item> CHERRY_POPSICLE = ITEMS.register("cherry_popsicle", () -> new DDFoodBase("cherry_popsicle", 1, 0.2F));
    public static final RegistryObject<Item> BLUEBERRY_POPSICLE = ITEMS.register("blueberry_popsicle", () -> new DDFoodBase("blueberry_popsicle", 1, 0.2F));
    public static final RegistryObject<Item> STRAWBERRY_POPSICLE = ITEMS.register("strawberry_popsicle", () -> new DDFoodBase("strawberry_popsicle", 1, 0.2F));
    public static final RegistryObject<Item> BANANA_POPSICLE = ITEMS.register("banana_popsicle", () -> new DDFoodBase("banana_popsicle", 1, 0.2F));

    // ========== 饼干面团 ==========
    public static final RegistryObject<Item> CHOCOLATE_CHIP_COOKIE_DOUGH = ITEMS.register("chocolate_chip_cookie_dough", () -> new DDFoodBase("chocolate_chip_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_MM_COOKIE_DOUGH = ITEMS.register("chocolate_chip_mm_cookie_dough", () -> new DDFoodBase("chocolate_chip_mm_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> CHOCOLATE_COOKIE_DOUGH = ITEMS.register("chocolate_cookie_dough", () -> new DDFoodBase("chocolate_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> CHOCOLATE_MM_COOKIE_DOUGH = ITEMS.register("chocolate_mm_cookie_dough", () -> new DDFoodBase("chocolate_mm_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> SUGAR_COOKIE_DOUGH = ITEMS.register("sugar_cookie_dough", () -> new DDFoodBase("sugar_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> SUGAR_MM_COOKIE_DOUGH = ITEMS.register("sugar_mm_cookie_dough", () -> new DDFoodBase("sugar_mm_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> MM_COOKIE_DOUGH = ITEMS.register("mm_cookie_dough", () -> new DDFoodBase("mm_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> PEANUT_BUTTER_COOKIE_DOUGH = ITEMS.register("peanut_butter_cookie_dough", () -> new DDFoodBase("peanut_butter_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> PEANUT_BUTTER_MM_COOKIE_DOUGH = ITEMS.register("peanut_butter_mm_cookie_dough", () -> new DDFoodBase("peanut_butter_mm_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> CREME_COOKIE_DOUGH = ITEMS.register("creme_cookie_dough", () -> new DDFoodBase("creme_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> MINT_CREME_COOKIE_DOUGH = ITEMS.register("mint_creme_cookie_dough", () -> new DDFoodBase("mint_creme_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> GINGER_SNAPS_COOKIE_DOUGH = ITEMS.register("ginger_snaps_cookie_dough", () -> new DDFoodBase("ginger_snaps_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> GINGERBREAD_MAN_COOKIE_DOUGH = ITEMS.register("gingerbread_man_cookie_dough", () -> new DDFoodBase("gingerbread_man_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> HEART_COOKIE_DOUGH = ITEMS.register("heart_cookie_dough", () -> new DDFoodBase("heart_cookie_dough", 1, 0.2F));
    public static final RegistryObject<Item> CANDY_BAR_COOKIE_DOUGH = ITEMS.register("candy_bar_cookie_dough", () -> new DDFoodBase("candy_bar_cookie_dough", 1, 0.2F));

    // ========== 饼干 ==========
    public static final RegistryObject<Item> CHOCOLATE_CHIP_COOKIE = ITEMS.register("chocolate_chip_cookie", () -> new DDFoodBase("chocolate_chip_cookie", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_COOKIE_MM = ITEMS.register("chocolate_chip_cookie_mm", () -> new DDFoodBase("chocolate_chip_cookie_mm", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_COOKIE = ITEMS.register("chocolate_cookie", () -> new DDFoodBase("chocolate_cookie", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_COOKIE_MM = ITEMS.register("chocolate_cookie_mm", () -> new DDFoodBase("chocolate_cookie_mm", 3, 0.4F));
    public static final RegistryObject<Item> SUGAR_COOKIE = ITEMS.register("sugar_cookie", () -> new DDFoodBase("sugar_cookie", 3, 0.4F));
    public static final RegistryObject<Item> SUGAR_COOKIE_MM = ITEMS.register("sugar_cookie_mm", () -> new DDFoodBase("sugar_cookie_mm", 3, 0.4F));
    public static final RegistryObject<Item> PEANUT_BUTTER_COOKIE = ITEMS.register("peanut_butter_cookie", () -> new DDFoodBase("peanut_butter_cookie", 3, 0.4F));
    public static final RegistryObject<Item> PEANUT_BUTTER_COOKIE_MM = ITEMS.register("peanut_butter_cookie_mm", () -> new DDFoodBase("peanut_butter_cookie_mm", 3, 0.4F));
    public static final RegistryObject<Item> CREME_COOKIE = ITEMS.register("creme_cookie", () -> new DDFoodBase("creme_cookie", 3, 0.4F));
    public static final RegistryObject<Item> CREME_COOKIE_CHOCOLATE_DIPPED = ITEMS.register("creme_cookie_chocolate_dipped", () -> new DDFoodBase("creme_cookie_chocolate_dipped", 3, 0.4F));
    public static final RegistryObject<Item> MINT_CREME_COOKIE = ITEMS.register("mint_creme_cookie", () -> new DDFoodBase("mint_creme_cookie", 3, 0.4F));
    public static final RegistryObject<Item> GINGER_SNAPS = ITEMS.register("ginger_snaps", () -> new DDFoodBase("ginger_snaps", 3, 0.4F));
    public static final RegistryObject<Item> GINGERBREAD_MAN = ITEMS.register("gingerbread_man", () -> new DDFoodBase("gingerbread_man", 3, 0.4F));
    public static final RegistryObject<Item> HALFMOON_COOKIE = ITEMS.register("halfmoon_cookie", () -> new DDFoodBase("halfmoon_cookie", 3, 0.4F));
    public static final RegistryObject<Item> MOON_PIE = ITEMS.register("moon_pie", () -> new DDFoodBase("moon_pie", 3, 0.4F));
    public static final RegistryObject<Item> HEART_COOKIE = ITEMS.register("heart_cookie", () -> new DDFoodBase("heart_cookie", 3, 0.4F));
    public static final RegistryObject<Item> HEART_COOKIE_VANILLA = ITEMS.register("heart_cookie_vanilla", () -> new DDFoodBase("heart_cookie_vanilla", 3, 0.4F));
    public static final RegistryObject<Item> HEART_COOKIE_CHOCOLATE = ITEMS.register("heart_cookie_chocolate", () -> new DDFoodBase("heart_cookie_chocolate", 3, 0.4F));
    public static final RegistryObject<Item> HEART_COOKIE_STRAWBERRY = ITEMS.register("heart_cookie_strawberry", () -> new DDFoodBase("heart_cookie_strawberry", 3, 0.4F));
    public static final RegistryObject<Item> HEART_COOKIE_RED_SUGAR = ITEMS.register("heart_cookie_red_sugar", () -> new DDFoodBase("heart_cookie_red_sugar", 3, 0.4F));
    public static final RegistryObject<Item> JAFFA_CAKE = ITEMS.register("jaffa_cake", () -> new DDFoodBase("jaffa_cake", 3, 0.4F));
    public static final RegistryObject<Item> CANNOLI = ITEMS.register("cannoli", () -> new DDFoodBase("cannoli", 3, 0.4F));
    public static final RegistryObject<Item> VANILLA_FRENCH_HORN = ITEMS.register("vanilla_french_horn", () -> new DDFoodBase("vanilla_french_horn", 3, 0.4F));
    public static final RegistryObject<Item> VANILLA_FRENCH_HORN_STRAWBERRY = ITEMS.register("vanilla_french_horn_strawberry", () -> new DDFoodBase("vanilla_french_horn_strawberry", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FRENCH_HORN = ITEMS.register("chocolate_french_horn", () -> new DDFoodBase("chocolate_french_horn", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FRENCH_HORN_STRAWBERRY = ITEMS.register("chocolate_french_horn_strawberry", () -> new DDFoodBase("chocolate_french_horn_strawberry", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_MILANO = ITEMS.register("chocolate_milano", () -> new DDFoodBase("chocolate_milano", 3, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_MILANO = ITEMS.register("strawberry_milano", () -> new DDFoodBase("strawberry_milano", 3, 0.4F));
    public static final RegistryObject<Item> MINT_MILANO = ITEMS.register("mint_milano", () -> new DDFoodBase("mint_milano", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_JAMMIE_DODGER = ITEMS.register("chocolate_jammie_dodger", () -> new DDFoodBase("chocolate_jammie_dodger", 3, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_JAMMIE_DODGER = ITEMS.register("strawberry_jammie_dodger", () -> new DDFoodBase("strawberry_jammie_dodger", 3, 0.4F));
    public static final RegistryObject<Item> PEPPERMINT_PATTY = ITEMS.register("peppermint_patty", () -> new DDFoodBase("peppermint_patty", 3, 0.4F));
    public static final RegistryObject<Item> FUDGE_STRIPED_COOKIE = ITEMS.register("fudge_striped_cookie", () -> new DDFoodBase("fudge_striped_cookie", 3, 0.4F));
    public static final RegistryObject<Item> THIN_MINT_COOKIE = ITEMS.register("thin_mint_cookie", () -> new DDFoodBase("thin_mint_cookie", 3, 0.4F));
    public static final RegistryObject<Item> SAMOAS_COOKIE = ITEMS.register("samoas_cookie", () -> new DDFoodBase("samoas_cookie", 3, 0.4F));
    public static final RegistryObject<Item> CANDY_BAR_COOKIE = ITEMS.register("candy_bar_cookie", () -> new DDFoodBase("candy_bar_cookie", 2, 0.2F));

    // ========== 甜甜圈 ==========
    public static final RegistryObject<Item> DONUT = ITEMS.register("donut", () -> new DDFoodBase("donut", 4, 0.4F));
    public static final RegistryObject<Item> POWDERED_DONUT = ITEMS.register("powdered_donut", () -> new DDFoodBase("powdered_donut", 4, 0.4F));
    public static final RegistryObject<Item> BOSTON_CREME_DONUT = ITEMS.register("boston_creme_donut", () -> new DDFoodBase("boston_creme_donut", 4, 0.4F));
    public static final RegistryObject<Item> BERLIN_CREME_DONUT = ITEMS.register("berlin_creme_donut", () -> new DDFoodBase("berlin_creme_donut", 4, 0.4F));
    public static final RegistryObject<Item> JELLY_DONUT = ITEMS.register("jelly_donut", () -> new DDFoodBase("jelly_donut", 4, 0.4F));
    public static final RegistryObject<Item> CINNAMON_BUN = ITEMS.register("cinnamon_bun", () -> new DDFoodBase("cinnamon_bun", 4, 0.4F));
    public static final RegistryObject<Item> GLAZED_DONUT = ITEMS.register("glazed_donut", () -> new DDFoodBase("glazed_donut", 4, 0.4F));
    public static final RegistryObject<Item> GLAZED_DONUT_SPRINKLES = ITEMS.register("glazed_donut_sprinkles", () -> new DDFoodBase("glazed_donut_sprinkles", 4, 0.4F));
    public static final RegistryObject<Item> GLAZED_DONUT_CHOCOLATE = ITEMS.register("glazed_donut_chocolate", () -> new DDFoodBase("glazed_donut_chocolate", 4, 0.4F));
    public static final RegistryObject<Item> GLAZED_DONUT_VANILLA = ITEMS.register("glazed_donut_vanilla", () -> new DDFoodBase("glazed_donut_vanilla", 4, 0.4F));
    public static final RegistryObject<Item> GLAZED_DONUT_STRAWBERRY = ITEMS.register("glazed_donut_strawberry", () -> new DDFoodBase("glazed_donut_strawberry", 4, 0.4F));
    public static final RegistryObject<Item> GLAZED_CHOCOLATE_DONUT = ITEMS.register("glazed_chocolate_donut", () -> new DDFoodBase("glazed_chocolate_donut", 4, 0.4F));
    public static final RegistryObject<Item> GLAZED_CHOCOLATE_DONUT_SPRINKLES = ITEMS.register("glazed_chocolate_donut_sprinkles", () -> new DDFoodBase("glazed_chocolate_donut_sprinkles", 4, 0.4F));
    public static final RegistryObject<Item> GLAZED_CHOCOLATE_DONUT_STRAWBERRY = ITEMS.register("glazed_chocolate_donut_strawberry", () -> new DDFoodBase("glazed_chocolate_donut_strawberry", 4, 0.4F));
    public static final RegistryObject<Item> GLAZED_CHOCOLATE_DONUT_VANILLA = ITEMS.register("glazed_chocolate_donut_vanilla", () -> new DDFoodBase("glazed_chocolate_donut_vanilla", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_DONUT = ITEMS.register("strawberry_frosted_donut", () -> new DDFoodBase("strawberry_frosted_donut", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_DONUT_SPRINKLES = ITEMS.register("strawberry_frosted_donut_sprinkles", () -> new DDFoodBase("strawberry_frosted_donut_sprinkles", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_DONUT_VANILLA = ITEMS.register("strawberry_frosted_donut_vanilla", () -> new DDFoodBase("strawberry_frosted_donut_vanilla", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_DONUT_CHOCOLATE = ITEMS.register("strawberry_frosted_donut_chocolate", () -> new DDFoodBase("strawberry_frosted_donut_chocolate", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_DONUT = ITEMS.register("chocolate_frosted_donut", () -> new DDFoodBase("chocolate_frosted_donut", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_DONUT_SPRINKLES = ITEMS.register("chocolate_frosted_donut_sprinkles", () -> new DDFoodBase("chocolate_frosted_donut_sprinkles", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_DONUT_VANILLA = ITEMS.register("chocolate_frosted_donut_vanilla", () -> new DDFoodBase("chocolate_frosted_donut_vanilla", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_DONUT_STRAWBERRY = ITEMS.register("chocolate_frosted_donut_strawberry", () -> new DDFoodBase("chocolate_frosted_donut_strawberry", 4, 0.4F));
    public static final RegistryObject<Item> VANILLA_FROSTED_DONUT = ITEMS.register("vanilla_frosted_donut", () -> new DDFoodBase("vanilla_frosted_donut", 4, 0.4F));
    public static final RegistryObject<Item> VANILLA_FROSTED_DONUT_SPRINKLES = ITEMS.register("vanilla_frosted_donut_sprinkles", () -> new DDFoodBase("vanilla_frosted_donut_sprinkles", 4, 0.4F));
    public static final RegistryObject<Item> VANILLA_FROSTED_DONUT_STRAWBERRY = ITEMS.register("vanilla_frosted_donut_strawberry", () -> new DDFoodBase("vanilla_frosted_donut_strawberry", 4, 0.4F));
    public static final RegistryObject<Item> VANILLA_FROSTED_DONUT_CHOCOLATE = ITEMS.register("vanilla_frosted_donut_chocolate", () -> new DDFoodBase("vanilla_frosted_donut_chocolate", 4, 0.4F));

    // 无麸质甜甜圈
    public static final RegistryObject<Item> GLUTEN_FREE_DONUT = ITEMS.register("gluten_free_donut", () -> new DDFoodBase("gluten_free_donut", 4, 0.4F));
    public static final RegistryObject<Item> GLUTEN_FREE_DONUT_SPRINKLES = ITEMS.register("gluten_free_donut_sprinkles", () -> new DDFoodBase("gluten_free_donut_sprinkles", 4, 0.4F));
    public static final RegistryObject<Item> GLUTEN_FREE_DONUT_VANILLA = ITEMS.register("gluten_free_donut_vanilla", () -> new DDFoodBase("gluten_free_donut_vanilla", 4, 0.4F));
    public static final RegistryObject<Item> GLUTEN_FREE_DONUT_CHOCOLATE = ITEMS.register("gluten_free_donut_chocolate", () -> new DDFoodBase("gluten_free_donut_chocolate", 4, 0.4F));
    public static final RegistryObject<Item> GLUTEN_FREE_DONUT_STRAWBERRY = ITEMS.register("gluten_free_donut_strawberry", () -> new DDFoodBase("gluten_free_donut_strawberry", 4, 0.4F));
    public static final RegistryObject<Item> GLAZED_GLUTEN_FREE_DONUT = ITEMS.register("glazed_gluten_free_donut", () -> new DDFoodBase("glazed_gluten_free_donut", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_GLUTEN_FREE_DONUT = ITEMS.register("strawberry_frosted_gluten_free_donut", () -> new DDFoodBase("strawberry_frosted_gluten_free_donut", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_GLUTEN_FREE_DONUT_SPRINKLES = ITEMS.register("strawberry_frosted_gluten_free_donut_sprinkles", () -> new DDFoodBase("strawberry_frosted_gluten_free_donut_sprinkles", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_GLUTEN_FREE_DONUT_CHOCOLATE = ITEMS.register("strawberry_frosted_gluten_free_donut_chocolate", () -> new DDFoodBase("strawberry_frosted_gluten_free_donut_chocolate", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_GLUTEN_FREE_DONUT_VANILLA = ITEMS.register("strawberry_frosted_gluten_free_donut_vanilla", () -> new DDFoodBase("strawberry_frosted_gluten_free_donut_vanilla", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_GLUTEN_FREE_DONUT = ITEMS.register("chocolate_frosted_gluten_free_donut", () -> new DDFoodBase("chocolate_frosted_gluten_free_donut", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_GLUTEN_FREE_DONUT_SPRINKLES = ITEMS.register("chocolate_frosted_gluten_free_donut_sprinkles", () -> new DDFoodBase("chocolate_frosted_gluten_free_donut_sprinkles", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_GLUTEN_FREE_DONUT_VANILLA = ITEMS.register("chocolate_frosted_gluten_free_donut_vanilla", () -> new DDFoodBase("chocolate_frosted_gluten_free_donut_vanilla", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_GLUTEN_FREE_DONUT_STRAWBERRY = ITEMS.register("chocolate_frosted_gluten_free_donut_strawberry", () -> new DDFoodBase("chocolate_frosted_gluten_free_donut_strawberry", 4, 0.4F));
    public static final RegistryObject<Item> VANILLA_FROSTED_GLUTEN_FREE_DONUT = ITEMS.register("vanilla_frosted_gluten_free_donut", () -> new DDFoodBase("vanilla_frosted_gluten_free_donut", 4, 0.4F));
    public static final RegistryObject<Item> VANILLA_FROSTED_GLUTEN_FREE_DONUT_SPRINKLES = ITEMS.register("vanilla_frosted_gluten_free_donut_sprinkles", () -> new DDFoodBase("vanilla_frosted_gluten_free_donut_sprinkles", 4, 0.4F));
    public static final RegistryObject<Item> VANILLA_FROSTED_GLUTEN_FREE_DONUT_STRAWBERRY = ITEMS.register("vanilla_frosted_gluten_free_donut_strawberry", () -> new DDFoodBase("vanilla_frosted_gluten_free_donut_strawberry", 4, 0.4F));
    public static final RegistryObject<Item> VANILLA_FROSTED_GLUTEN_FREE_DONUT_CHOCOLATE = ITEMS.register("vanilla_frosted_gluten_free_donut_chocolate", () -> new DDFoodBase("vanilla_frosted_gluten_free_donut_chocolate", 4, 0.4F));
    public static final RegistryObject<Item> POWDERED_GLUTEN_FREE_DONUT = ITEMS.register("powdered_gluten_free_donut", () -> new DDFoodBase("powdered_gluten_free_donut", 4, 0.4F));

    // ========== 整个派 ==========
    public static final RegistryObject<Item> WHOLE_APPLE_PIE = ITEMS.register("whole_apple_pie", () -> new DDFoodBase("whole_apple_pie", 8, 4.8F, "allypoo2001"));
    public static final RegistryObject<Item> WHOLE_PUMPKIN_PIE = ITEMS.register("whole_pumpkin_pie", () -> new DDFoodBase("whole_pumpkin_pie", 8, 4.8F));
    public static final RegistryObject<Item> WHOLE_STRAWBERRY_PIE = ITEMS.register("whole_strawberry_pie", () -> new DDFoodBase("whole_strawberry_pie", 8, 4.8F));
    public static final RegistryObject<Item> WHOLE_CHOCOLATE_PIE = ITEMS.register("whole_chocolate_pie", () -> new DDFoodBase("whole_chocolate_pie", 8, 4.8F));
    public static final RegistryObject<Item> WHOLE_CHERRY_PIE = ITEMS.register("whole_cherry_pie", () -> new DDFoodBase("whole_cherry_pie", 8, 4.8F));
    public static final RegistryObject<Item> WHOLE_BLUEBERRY_PIE = ITEMS.register("whole_blueberry_pie", () -> new DDFoodBase("whole_blueberry_pie", 8, 4.8F));
    public static final RegistryObject<Item> WHOLE_PECAN_PIE = ITEMS.register("whole_pecan_pie", () -> new DDFoodBase("whole_pecan_pie", 8, 4.8F, "allypoo2001"));
    public static final RegistryObject<Item> WHOLE_BANANA_CREAM_PIE = ITEMS.register("whole_banana_cream_pie", () -> new DDFoodBase("whole_banana_cream_pie", 8, 4.8F));
    public static final RegistryObject<Item> WHOLE_BLACKBERRY_PIE = ITEMS.register("whole_blackberry_pie", () -> new DDFoodBase("whole_blackberry_pie", 8, 4.8F));
    public static final RegistryObject<Item> WHOLE_COCONUT_CREAM_PIE = ITEMS.register("whole_coconut_cream_pie", () -> new DDFoodBase("whole_coconut_cream_pie", 8, 4.8F));

    // ========== 派切片 ==========
    public static final RegistryObject<Item> APPLE_PIE = ITEMS.register("apple_pie", () -> new DDFoodBase("apple_pie", 4, 0.8F));
    public static final RegistryObject<Item> PUMPKIN_PIE = ITEMS.register("pumpkin_pie", () -> new DDFoodBase("pumpkin_pie", 4, 0.8F));
    public static final RegistryObject<Item> STRAWBERRY_PIE = ITEMS.register("strawberry_pie", () -> new DDFoodBase("strawberry_pie", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_PIE = ITEMS.register("chocolate_pie", () -> new DDFoodBase("chocolate_pie", 4, 0.8F));
    public static final RegistryObject<Item> CHERRY_PIE = ITEMS.register("cherry_pie", () -> new DDFoodBase("cherry_pie", 4, 0.8F));
    public static final RegistryObject<Item> BLUEBERRY_PIE = ITEMS.register("blueberry_pie", () -> new DDFoodBase("blueberry_pie", 4, 0.8F));
    public static final RegistryObject<Item> PECAN_PIE = ITEMS.register("pecan_pie", () -> new DDFoodBase("pecan_pie", 4, 0.8F, "allypoo2001"));
    public static final RegistryObject<Item> BANANA_CREAM_PIE = ITEMS.register("banana_cream_pie", () -> new DDFoodBase("banana_cream_pie", 4, 0.8F));
    public static final RegistryObject<Item> BLACKBERRY_PIE = ITEMS.register("blackberry_pie", () -> new DDFoodBase("blackberry_pie", 4, 0.8F));
    public static final RegistryObject<Item> COCONUT_CREAM_PIE = ITEMS.register("coconut_cream_pie", () -> new DDFoodBase("coconut_cream_pie", 4, 0.8F));

    // ========== 馅饼基底 ==========
    public static final RegistryObject<Item> POPTART_BASE = ITEMS.register("poptart_base", () -> new DDFoodBase("poptart_base", 2, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_POPTART_BASE = ITEMS.register("chocolate_poptart_base", () -> new DDFoodBase("chocolate_poptart_base", 2, 0.4F));

    // ========== 馅饼 ==========
    public static final RegistryObject<Item> STRAWBERRY_POPTART = ITEMS.register("strawberry_poptart", () -> new DDFoodBase("strawberry_poptart", 3, 0.4F));
    public static final RegistryObject<Item> BROWN_SUGAR_POPTART = ITEMS.register("brown_sugar_poptart", () -> new DDFoodBase("brown_sugar_poptart", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_POPTART = ITEMS.register("chocolate_chip_poptart", () -> new DDFoodBase("chocolate_chip_poptart", 3, 0.4F));
    public static final RegistryObject<Item> MINECRAFT_POPTART = ITEMS.register("minecraft_poptart", () -> new DDFoodBase("minecraft_poptart", 3, 0.4F, "LUEZIS"));
    public static final RegistryObject<Item> COOKIES_AND_CREME_POPTART = ITEMS.register("cookies_and_creme_poptart", () -> new DDFoodBase("cookies_and_creme_poptart", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FUDGE_POPTART = ITEMS.register("chocolate_fudge_poptart", () -> new DDFoodBase("chocolate_fudge_poptart", 3, 0.4F));
    public static final RegistryObject<Item> SMORES_POPTART = ITEMS.register("smores_poptart", () -> new DDFoodBase("smores_poptart", 3, 0.4F));
    public static final RegistryObject<Item> CINNAMON_ROLL_POPTART = ITEMS.register("cinnamon_roll_poptart", () -> new DDFoodBase("cinnamon_roll_poptart", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_CUPCAKE_POPTART = ITEMS.register("chocolate_cupcake_poptart", () -> new DDFoodBase("chocolate_cupcake_poptart", 3, 0.4F));
    public static final RegistryObject<Item> CONFETTI_CUPCAKE_POPTART = ITEMS.register("confetti_cupcake_poptart", () -> new DDFoodBase("confetti_cupcake_poptart", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_COOKIE_DOUGH_POPTART = ITEMS.register("chocolate_chip_cookie_dough_poptart", () -> new DDFoodBase("chocolate_chip_cookie_dough_poptart", 3, 0.4F));
    public static final RegistryObject<Item> BLUEBERRY_POPTART = ITEMS.register("blueberry_poptart", () -> new DDFoodBase("blueberry_poptart", 3, 0.4F));
    public static final RegistryObject<Item> CHERRY_POPTART = ITEMS.register("cherry_poptart", () -> new DDFoodBase("cherry_poptart", 3, 0.4F));
    public static final RegistryObject<Item> HOT_FUDGE_SUNDAE = ITEMS.register("hot_fudge_sundae", () -> new DDFoodBase("hot_fudge_sundae", 6, 0.6F));
    public static final RegistryObject<Item> HOT_FUDGE_SUNDAE_POPTART = ITEMS.register("hot_fudge_sundae_poptart", () -> new DDFoodBase("hot_fudge_sundae_poptart", 3, 0.4F));
    public static final RegistryObject<Item> BLACKBERRY_POPTART = ITEMS.register("blackberry_poptart", () -> new DDFoodBase("blackberry_poptart", 3, 0.4F));

    // ========== 煎饼和华夫饼面糊 ==========
    public static final RegistryObject<Item> PANCAKE_BATTER = ITEMS.register("pancake_batter", () -> new DDItemBase("pancake_batter"));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_PANCAKE_BATTER = ITEMS.register("chocolate_chip_pancake_batter", () -> new DDItemBase("chocolate_chip_pancake_batter"));
    public static final RegistryObject<Item> BLUEBERRY_PANCAKE_BATTER = ITEMS.register("blueberry_pancake_batter", () -> new DDItemBase("blueberry_pancake_batter"));
    public static final RegistryObject<Item> CHOCOLATE_PANCAKE_BATTER = ITEMS.register("chocolate_pancake_batter", () -> new DDItemBase("chocolate_pancake_batter"));
    public static final RegistryObject<Item> WAFFLE_BATTER = ITEMS.register("waffle_batter", () -> new DDItemBase("waffle_batter"));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_WAFFLE_BATTER = ITEMS.register("chocolate_chip_waffle_batter", () -> new DDItemBase("chocolate_chip_waffle_batter"));
    public static final RegistryObject<Item> BLUEBERRY_WAFFLE_BATTER = ITEMS.register("blueberry_waffle_batter", () -> new DDItemBase("blueberry_waffle_batter"));
    public static final RegistryObject<Item> CHOCOLATE_WAFFLE_BATTER = ITEMS.register("chocolate_waffle_batter", () -> new DDItemBase("chocolate_waffle_batter"));
    public static final RegistryObject<Item> FRENCH_TOAST_BATTER = ITEMS.register("french_toast_batter", () -> new DDItemBase("french_toast_batter"));

    // ========== 煎饼 ==========
    public static final RegistryObject<Item> PANCAKE = ITEMS.register("pancake", () -> new DDFoodBase("pancake", 4, 0.8F, "forrys_"));
    public static final RegistryObject<Item> PANCAKE_SYRUP = ITEMS.register("pancake_syrup", () -> new DDFoodBase("pancake_syrup", 4, 0.8F));
    public static final RegistryObject<Item> PANCAKE_SYRUP_BUTTER = ITEMS.register("pancake_syrup_butter", () -> new DDFoodBase("pancake_syrup_butter", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_PANCAKE = ITEMS.register("chocolate_chip_pancake", () -> new DDFoodBase("chocolate_chip_pancake", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_PANCAKE_SYRUP = ITEMS.register("chocolate_chip_pancake_syrup", () -> new DDFoodBase("chocolate_chip_pancake_syrup", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_PANCAKE_SYRUP_BUTTER = ITEMS.register("chocolate_chip_pancake_syrup_butter", () -> new DDFoodBase("chocolate_chip_pancake_syrup_butter", 4, 0.8F));
    public static final RegistryObject<Item> BLUEBERRY_PANCAKE = ITEMS.register("blueberry_pancake", () -> new DDFoodBase("blueberry_pancake", 4, 0.8F));
    public static final RegistryObject<Item> BLUEBERRY_PANCAKE_SYRUP = ITEMS.register("blueberry_pancake_syrup", () -> new DDFoodBase("blueberry_pancake_syrup", 4, 0.8F));
    public static final RegistryObject<Item> BLUEBERRY_PANCAKE_SYRUP_BUTTER = ITEMS.register("blueberry_pancake_syrup_butter", () -> new DDFoodBase("blueberry_pancake_syrup_butter", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_PANCAKE = ITEMS.register("chocolate_pancake", () -> new DDFoodBase("chocolate_pancake", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_PANCAKE_CHOCOLATE_SYRUP = ITEMS.register("chocolate_pancake_chocolate_syrup", () -> new DDFoodBase("chocolate_pancake_chocolate_syrup", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_PANCAKE_SYRUP_BUTTER = ITEMS.register("chocolate_pancake_syrup_butter", () -> new DDFoodBase("chocolate_pancake_syrup_butter", 4, 0.8F));

    // ========== 华夫饼 ==========
    public static final RegistryObject<Item> WAFFLE = ITEMS.register("waffle", () -> new DDFoodBase("waffle", 4, 0.8F));
    public static final RegistryObject<Item> WAFFLE_SYRUP = ITEMS.register("waffle_syrup", () -> new DDFoodBase("waffle_syrup", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_WAFFLE = ITEMS.register("chocolate_chip_waffle", () -> new DDFoodBase("chocolate_chip_waffle", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_CHIP_WAFFLE_SYRUP = ITEMS.register("chocolate_chip_waffle_syrup", () -> new DDFoodBase("chocolate_chip_waffle_syrup", 4, 0.8F));
    public static final RegistryObject<Item> BLUEBERRY_WAFFLE = ITEMS.register("blueberry_waffle", () -> new DDFoodBase("blueberry_waffle", 4, 0.8F));
    public static final RegistryObject<Item> BLUEBERRY_WAFFLE_SYRUP = ITEMS.register("blueberry_waffle_syrup", () -> new DDFoodBase("blueberry_waffle_syrup", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_WAFFLE = ITEMS.register("chocolate_waffle", () -> new DDFoodBase("chocolate_waffle", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_WAFFLE_CHOCOLATE_SYRUP = ITEMS.register("chocolate_waffle_chocolate_syrup", () -> new DDFoodBase("chocolate_waffle_chocolate_syrup", 4, 0.8F));

    // ========== 法式吐司 ==========
    public static final RegistryObject<Item> FRENCH_TOAST = ITEMS.register("french_toast", () -> new DDFoodBase("french_toast", 4, 0.8F));
    public static final RegistryObject<Item> FRENCH_TOAST_SYRUP = ITEMS.register("french_toast_syrup", () -> new DDFoodBase("french_toast_syrup", 4, 0.8F));

    // ========== 布朗尼面糊 ==========
    public static final RegistryObject<Item> CHOCOLATE_BROWNIE_BATTER = ITEMS.register("chocolate_brownie_batter", () -> new DDItemBase("chocolate_brownie_batter"));
    public static final RegistryObject<Item> PEANUT_BUTTER_BROWNIE_BATTER = ITEMS.register("peanut_butter_brownie_batter", () -> new DDItemBase("peanut_butter_brownie_batter"));
    public static final RegistryObject<Item> CARAMEL_BROWNIE_BATTER = ITEMS.register("caramel_brownie_batter", () -> new DDItemBase("caramel_brownie_batter"));
    public static final RegistryObject<Item> MINT_BROWNIE_BATTER = ITEMS.register("mint_brownie_batter", () -> new DDItemBase("mint_brownie_batter"));
    public static final RegistryObject<Item> COFFEE_CAKE_BATTER = ITEMS.register("coffee_cake_batter", () -> new DDItemBase("coffee_cake_batter"));

    // ========== 糖果 ==========
    public static final RegistryObject<Item> MMS = ITEMS.register("mms", () -> new DDFoodBase("mms", 1, 0.2F));
    public static final RegistryObject<Item> PEPPERMINT = ITEMS.register("peppermint", () -> new DDCandyBase("peppermint", 1, 0.2F, 8));
    public static final RegistryObject<Item> CHOCOLATE_STRAWBERRY = ITEMS.register("chocolate_strawberry", () -> new DDFoodBase("chocolate_strawberry", 2, 2.4F));

    public static final RegistryObject<Item> TWIX = ITEMS.register("twix", () -> new DDCandyBase("twix", 3, 0.6F, 10));
    public static final RegistryObject<Item> MILKY_WAY = ITEMS.register("milky_way", () -> new DDCandyBase("milky_way", 3, 0.6F, 10));
    public static final RegistryObject<Item> CRUNCH_BAR = ITEMS.register("crunch_bar", () -> new DDCandyBase("crunch_bar", 3, 0.6F, 15));
    public static final RegistryObject<Item> PEANUT_BRITTLE = ITEMS.register("peanut_brittle", () -> new DDFoodBase("peanut_brittle", 4, 0.6F));
    public static final RegistryObject<Item> PEANUT_BUTTER_CUP = ITEMS.register("peanut_butter_cup", () -> new DDCandyBase("peanut_butter_cup", 3, 0.6F, 10));
    public static final RegistryObject<Item> PAYDAY = ITEMS.register("payday", () -> new DDCandyBase("payday", 3, 0.6F, 10));
    public static final RegistryObject<Item> SNICKERS = ITEMS.register("snickers", () -> new DDCandyBase("snickers", 3, 0.6F, 10));
    public static final RegistryObject<Item> KITKAT = ITEMS.register("kitkat", () -> new DDCandyBase("kitkat", 3, 0.6F, 10));
    public static final RegistryObject<Item> ROLO = ITEMS.register("rolo", () -> new DDCandyBase("rolo", 1, 0.3F, 10));
    public static final RegistryObject<Item> HERSHEY_KISS = ITEMS.register("hershey_kiss", () -> new DDCandyBase("hershey_kiss", 1, 0.3F, 10));
    public static final RegistryObject<Item> MARS_BAR = ITEMS.register("mars_bar", () -> new DDCandyBase("mars_bar", 3, 0.6F, 10));
    public static final RegistryObject<Item> COTTON_CANDY = ITEMS.register("cotton_candy", () -> new DDFoodBase("cotton_candy", 1, 0.3F));
    public static final RegistryObject<Item> COTTON_CANDY_STRAWBERRY = ITEMS.register("cotton_candy_strawberry", () -> new DDFoodBase("cotton_candy_strawberry", 1, 0.3F));
    public static final RegistryObject<Item> CANDY_CORN = ITEMS.register("candy_corn", () -> new DDCandyBase("candy_corn", 1, 0.1F, 8));
    public static final RegistryObject<Item> THREE_MUSKETEERS = ITEMS.register("three_musketeers", () -> new DDCandyBase("three_musketeers", 1, 0.3F, 10));
    public static final RegistryObject<Item> VANILLA_NOUGAT = ITEMS.register("vanilla_nougat", () -> new DDCandyBase("vanilla_nougat", 1, 0.8F, 10));
    public static final RegistryObject<Item> VANILLA_NOUGAT_NUTS = ITEMS.register("vanilla_nougat_nuts", () -> new DDCandyBase("vanilla_nougat_2", 1, 0.8F, 10));
    public static final RegistryObject<Item> CHOCOLATE_NOUGAT = ITEMS.register("chocolate_nougat", () -> new DDCandyBase("chocolate_nougat", 1, 0.8F, 10));
    public static final RegistryObject<Item> CHOCOLATE_NOUGAT_NUTS = ITEMS.register("chocolate_nougat_nuts", () -> new DDCandyBase("chocolate_nougat_2", 1, 0.8F, 10));
    public static final RegistryObject<Item> BLACK_LICORICE = ITEMS.register("black_licorice", () -> new DDCandyBase("black_licorice", 1, 0.7F, 10));
    public static final RegistryObject<Item> RED_LICORICE = ITEMS.register("red_licorice", () -> new DDCandyBase("red_licorice", 1, 0.7F, 10));

    // ========== 棒棒糖 ==========
    public static final RegistryObject<Item> BANANA_LOLLIPOP = ITEMS.register("banana_lollipop", () -> new DDCandyBase("banana_lollipop", 1, 0.2F, 8));
    public static final RegistryObject<Item> CHERRY_LOLLIPOP = ITEMS.register("cherry_lollipop", () -> new DDCandyBase("cherry_lollipop", 1, 0.2F, 8));
    public static final RegistryObject<Item> BLUEBERRY_LOLLIPOP = ITEMS.register("blueberry_lollipop", () -> new DDCandyBase("blueberry_lollipop", 1, 0.2F, 8));
    public static final RegistryObject<Item> STRAWBERRY_LOLLIPOP = ITEMS.register("strawberry_lollipop", () -> new DDCandyBase("strawberry_lollipop", 1, 0.2F, 8));
    public static final RegistryObject<Item> PEPPERMINT_LOLLIPOP = ITEMS.register("peppermint_lollipop", () -> new DDCandyBase("peppermint_lollipop", 1, 0.2F, 8));

    // ========== 果冻 ==========
    public static final RegistryObject<Item> CHERRY_JELLO = ITEMS.register("cherry_jello", () -> new DDCandyBase("cherry_jello", 1, 0.2F, 12));
    public static final RegistryObject<Item> MELON_JELLO = ITEMS.register("melon_jello", () -> new DDCandyBase("melon_jello", 1, 0.2F, 12));
    public static final RegistryObject<Item> STRAWBERRY_JELLO = ITEMS.register("strawberry_jello", () -> new DDCandyBase("strawberry_jello", 1, 0.2F, 12));
    public static final RegistryObject<Item> BLUEBERRY_JELLO = ITEMS.register("blueberry_jello", () -> new DDCandyBase("blueberry_jello", 1, 0.2F, 12));

    // ========== 小熊软糖 ==========
    public static final RegistryObject<Item> GUMMY_BEAR_BASE = ITEMS.register("gummy_bear_base", () -> new DDCandyBase("gummy_bear_base", 1, 0.2F, 12, "MattyBoii_360"));
    public static final RegistryObject<Item> CHERRY_GUMMY_BEAR = ITEMS.register("cherry_gummy_bear", () -> new DDCandyBase("cherry_gummy_bear", 1, 0.2F, 12));
    public static final RegistryObject<Item> MELON_GUMMY_BEAR = ITEMS.register("melon_gummy_bear", () -> new DDCandyBase("melon_gummy_bear", 1, 0.2F, 12));
    public static final RegistryObject<Item> STRAWBERRY_GUMMY_BEAR = ITEMS.register("strawberry_gummy_bear", () -> new DDCandyBase("strawberry_gummy_bear", 1, 0.2F, 12));
    public static final RegistryObject<Item> BLUEBERRY_GUMMY_BEAR = ITEMS.register("blueberry_gummy_bear", () -> new DDCandyBase("blueberry_gummy_bear", 1, 0.2F, 12));
    public static final RegistryObject<Item> GREEN_APPLE_GUMMY_BEAR = ITEMS.register("green_apple_gummy_bear", () -> new DDCandyBase("green_apple_gummy_bear", 1, 0.2F, 12));

    // ========== 羊角面包和可丽饼 ==========
    public static final RegistryObject<Item> CROISSANT = ITEMS.register("croissant", () -> new DDFoodBase("croissant", 5, 0.8F));
    public static final RegistryObject<Item> CREPE = ITEMS.register("crepe", () -> new DDFoodBase("crepe", 4, 0.8F));
    public static final RegistryObject<Item> CREPE_CHOCOLATE_SYRUP = ITEMS.register("crepe_chocolate_syrup", () -> new DDFoodBase("crepe_chocolate_syrup", 4, 0.8F));
    public static final RegistryObject<Item> CREPE_CHOCOLATE_STRAWBERRY = ITEMS.register("crepe_chocolate_strawberry", () -> new DDFoodBase("crepe_chocolate_strawberry", 4, 0.8F));
    public static final RegistryObject<Item> CREPE_CHOCOLATE_MIXED_BERRY = ITEMS.register("crepe_chocolate_mixed_berry", () -> new DDFoodBase("crepe_chocolate_mixed_berry", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_CREPE = ITEMS.register("chocolate_crepe", () -> new DDFoodBase("chocolate_crepe", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_CREPE_DOUBLE_CHOCOLATE = ITEMS.register("chocolate_crepe_double_chocolate", () -> new DDFoodBase("chocolate_crepe_double_chocolate", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_CREPE_STRAWBERRY = ITEMS.register("chocolate_crepe_strawberry", () -> new DDFoodBase("chocolate_crepe_strawberry", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_CREPE_MIXED_BERRY = ITEMS.register("chocolate_crepe_mixed_berry", () -> new DDFoodBase("chocolate_crepe_mixed_berry", 4, 0.8F));

    // ========== 其他甜点 ==========
    public static final RegistryObject<Item> STRAWBERRY_SHORTCAKE = ITEMS.register("strawberry_shortcake", () -> new DDFoodBase("strawberry_shortcake", 4, 1.4F));
    public static final RegistryObject<Item> CHOCOLATE_STRAWBERRY_SHORTCAKE = ITEMS.register("chocolate_strawberry_shortcake", () -> new DDFoodBase("chocolate_strawberry_shortcake", 4, 1.4F));
    public static final RegistryObject<Item> CARAMEL_APPLE = ITEMS.register("caramel_apple", () -> new DDFoodBase("caramel_apple", 6, 1.4F));

    // ========== 软心豆粒糖 ==========
    public static final RegistryObject<Item> VANILLA_JELLYBEAN = ITEMS.register("vanilla_jellybean", () -> new DDCandyBase("vanilla_jellybean", 1, 0.2F, 8));
    public static final RegistryObject<Item> CHOCOLATE_JELLYBEAN = ITEMS.register("chocolate_jellybean", () -> new DDCandyBase("chocolate_jellybean", 1, 0.2F, 8));
    public static final RegistryObject<Item> STRAWBERRY_JELLYBEAN = ITEMS.register("strawberry_jellybean", () -> new DDCandyBase("strawberry_jellybean", 1, 0.2F, 8));
    public static final RegistryObject<Item> GREEN_APPLE_JELLYBEAN = ITEMS.register("green_apple_jellybean", () -> new DDCandyBase("green_apple_jellybean", 1, 0.2F, 8));
    public static final RegistryObject<Item> BLUEBERRY_JELLYBEAN = ITEMS.register("blueberry_jellybean", () -> new DDCandyBase("blueberry_jellybean", 1, 0.2F, 8));
    public static final RegistryObject<Item> BANANA_JELLYBEAN = ITEMS.register("banana_jellybean", () -> new DDCandyBase("banana_jellybean", 1, 0.2F, 8));
    public static final RegistryObject<Item> CHERRY_JELLYBEAN = ITEMS.register("cherry_jellybean", () -> new DDCandyBase("cherry_jellybean", 1, 0.2F, 8));

    // ========== 拐杖糖 ==========
    public static final RegistryObject<Item> CANDYCANE = ITEMS.register("candycane", () -> new DDCandyBase("candycane", 1, 0.4F, 15));
    public static final RegistryObject<Item> CHOCOLATE_CANDYCANE = ITEMS.register("chocolate_candycane", () -> new DDCandyBase("chocolate_candycane", 1, 0.4F, 15));
    public static final RegistryObject<Item> STRAWBERRY_CANDYCANE = ITEMS.register("strawberry_candycane", () -> new DDCandyBase("strawberry_candycane", 1, 0.4F, 15));
    public static final RegistryObject<Item> GREEN_APPLE_CANDYCANE = ITEMS.register("green_apple_candycane", () -> new DDCandyBase("green_apple_candycane", 1, 0.4F, 15));
    public static final RegistryObject<Item> BLUEBERRY_CANDYCANE = ITEMS.register("blueberry_candycane", () -> new DDCandyBase("blueberry_candycane", 1, 0.4F, 15));
    public static final RegistryObject<Item> BANANA_CANDYCANE = ITEMS.register("banana_candycane", () -> new DDCandyBase("banana_candycane", 1, 0.4F, 15));
    public static final RegistryObject<Item> CHERRY_CANDYCANE = ITEMS.register("cherry_candycane", () -> new DDCandyBase("cherry_candycane", 1, 0.4F, 15));

    // ========== 马卡龙 ==========
    public static final RegistryObject<Item> VANILLA_MACARON = ITEMS.register("vanilla_macaron", () -> new DDFoodBase("vanilla_macaron", 3, 0.4F, "minecrafter4112"));
    public static final RegistryObject<Item> CHOCOLATE_MACARON = ITEMS.register("chocolate_macaron", () -> new DDFoodBase("chocolate_macaron", 3, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_MACARON = ITEMS.register("strawberry_macaron", () -> new DDFoodBase("strawberry_macaron", 3, 0.4F));
    public static final RegistryObject<Item> MINT_MACARON = ITEMS.register("mint_macaron", () -> new DDFoodBase("mint_macaron", 3, 0.4F));
    public static final RegistryObject<Item> BLUEBERRY_MACARON = ITEMS.register("blueberry_macaron", () -> new DDFoodBase("blueberry_macaron", 3, 0.4F));
    public static final RegistryObject<Item> BANANA_MACARON = ITEMS.register("banana_macaron", () -> new DDFoodBase("banana_macaron", 3, 0.4F));
    public static final RegistryObject<Item> CHERRY_MACARON = ITEMS.register("cherry_macaron", () -> new DDFoodBase("cherry_macaron", 3, 0.4F));

    // ========== 松饼面团 ==========
    public static final RegistryObject<Item> VANILLA_MUFFIN_DOUGH = ITEMS.register("vanilla_muffin_dough", () -> new DDItemBase("vanilla_muffin_dough"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_DOUGH_BLUEBERRY = ITEMS.register("vanilla_muffin_dough_blueberry", () -> new DDItemBase("vanilla_muffin_dough_blueberry"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_DOUGH_CHOCOLATE_CHIP = ITEMS.register("vanilla_muffin_dough_chocolate_chip", () -> new DDItemBase("vanilla_muffin_dough_chocolate_chip"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_DOUGH_STRAWBERRY = ITEMS.register("vanilla_muffin_dough_strawberry", () -> new DDItemBase("vanilla_muffin_dough_strawberry"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_DOUGH_POPPY_SEED = ITEMS.register("vanilla_muffin_dough_poppy_seed", () -> new DDItemBase("vanilla_muffin_dough_poppy_seed"));
    public static final RegistryObject<Item> VANILLA_MUFFIN_DOUGH_BLACKBERRY = ITEMS.register("vanilla_muffin_dough_blackberry", () -> new DDItemBase("vanilla_muffin_dough_blackberry"));
    public static final RegistryObject<Item> BANANA_BREAD_MUFFIN_DOUGH = ITEMS.register("banana_bread_muffin_dough", () -> new DDItemBase("banana_bread_muffin_dough"));
    public static final RegistryObject<Item> BANANA_BREAD_MUFFIN_DOUGH_CHOCOLATE = ITEMS.register("banana_bread_muffin_dough_chocolate", () -> new DDItemBase("banana_bread_muffin_dough_chocolate"));

    // ========== 松饼 ==========
    public static final RegistryObject<Item> VANILLA_MUFFIN = ITEMS.register("vanilla_muffin", () -> new DDFoodBase("vanilla_muffin", 6, 0.8F));
    public static final RegistryObject<Item> VANILLA_MUFFIN_BLUEBERRY = ITEMS.register("vanilla_muffin_blueberry", () -> new DDFoodBase("vanilla_muffin_blueberry", 6, 0.8F));
    public static final RegistryObject<Item> VANILLA_MUFFIN_CHOCOLATE_CHIP = ITEMS.register("vanilla_muffin_chocolate_chip", () -> new DDFoodBase("vanilla_muffin_chocolate_chip", 6, 0.8F));
    public static final RegistryObject<Item> VANILLA_MUFFIN_STRAWBERRY = ITEMS.register("vanilla_muffin_strawberry", () -> new DDFoodBase("vanilla_muffin_strawberry", 6, 0.8F));
    public static final RegistryObject<Item> VANILLA_MUFFIN_POPPY_SEED = ITEMS.register("vanilla_muffin_poppy_seed", () -> new DDFoodBase("vanilla_muffin_poppy_seed", 6, 0.8F));
    public static final RegistryObject<Item> VANILLA_MUFFIN_BLACKBERRY = ITEMS.register("vanilla_muffin_blackberry", () -> new DDFoodBase("vanilla_muffin_blackberry", 6, 0.8F));
    public static final RegistryObject<Item> BANANA_BREAD_MUFFIN = ITEMS.register("banana_bread_muffin", () -> new DDFoodBase("banana_bread_muffin", 6, 0.8F));
    public static final RegistryObject<Item> BANANA_BREAD_MUFFIN_CHOCOLATE = ITEMS.register("banana_bread_muffin_chocolate", () -> new DDFoodBase("banana_bread_muffin_chocolate", 6, 0.8F));

    // ========== 椒盐脆饼 ==========
    public static final RegistryObject<Item> PRETZEL = ITEMS.register("pretzel", () -> new DDFoodBase("pretzel", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_PRETZEL = ITEMS.register("chocolate_pretzel", () -> new DDFoodBase("chocolate_pretzel", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_PRETZEL_WHITE_FROSTED = ITEMS.register("chocolate_pretzel_white_frosted", () -> new DDFoodBase("chocolate_pretzel_white_frosted", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_PRETZEL_SPRINKLES = ITEMS.register("chocolate_pretzel_sprinkles", () -> new DDFoodBase("chocolate_pretzel_sprinkles", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_PRETZEL_WHITE_SPRINKLES = ITEMS.register("chocolate_pretzel_white_sprinkles", () -> new DDFoodBase("chocolate_pretzel_white_sprinkles", 3, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_PRETZEL = ITEMS.register("strawberry_pretzel", () -> new DDFoodBase("strawberry_pretzel", 3, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_PRETZEL_SPRINKLES = ITEMS.register("strawberry_pretzel_sprinkles", () -> new DDFoodBase("strawberry_pretzel_sprinkles", 3, 0.4F));
    public static final RegistryObject<Item> MINT_PRETZEL = ITEMS.register("mint_pretzel", () -> new DDFoodBase("mint_pretzel", 3, 0.4F));
    public static final RegistryObject<Item> MINT_PRETZEL_SPRINKLES = ITEMS.register("mint_pretzel_sprinkles", () -> new DDFoodBase("mint_pretzel_sprinkles", 3, 0.4F));
    public static final RegistryObject<Item> GLUTEN_FREE_PRETZEL = ITEMS.register("gluten_free_pretzel", () -> new DDFoodBase("gluten_free_pretzel", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_GLUTEN_FREE_PRETZEL = ITEMS.register("chocolate_gluten_free_pretzel", () -> new DDFoodBase("chocolate_gluten_free_pretzel", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_GLUTEN_FREE_PRETZEL_WHITE = ITEMS.register("chocolate_gluten_free_pretzel_white", () -> new DDFoodBase("chocolate_gluten_free_pretzel_white", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_GLUTEN_FREE_PRETZEL_SPRINKLES = ITEMS.register("chocolate_gluten_free_pretzel_sprinkles", () -> new DDFoodBase("chocolate_gluten_free_pretzel_sprinkles", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_GLUTEN_FREE_PRETZEL_WHITE_SPRINKLES = ITEMS.register("chocolate_gluten_free_pretzel_white_sprinkles", () -> new DDFoodBase("chocolate_gluten_free_pretzel_white_sprinkles", 3, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_GLUTEN_FREE_PRETZEL = ITEMS.register("strawberry_gluten_free_pretzel", () -> new DDFoodBase("strawberry_gluten_free_pretzel", 3, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_GLUTEN_FREE_PRETZEL_SPRINKLES = ITEMS.register("strawberry_gluten_free_pretzel_sprinkles", () -> new DDFoodBase("strawberry_gluten_free_pretzel_sprinkles", 3, 0.4F));
    public static final RegistryObject<Item> MINT_GLUTEN_FREE_PRETZEL = ITEMS.register("mint_gluten_free_pretzel", () -> new DDFoodBase("mint_gluten_free_pretzel", 3, 0.4F));
    public static final RegistryObject<Item> MINT_GLUTEN_FREE_PRETZEL_SPRINKLES = ITEMS.register("mint_gluten_free_pretzel_sprinkles", () -> new DDFoodBase("mint_gluten_free_pretzel_sprinkles", 3, 0.4F));

    // ========== 布朗尼 ==========
    public static final RegistryObject<Item> CHOCOLATE_BROWNIE = ITEMS.register("chocolate_brownie", () -> new DDFoodBase("chocolate_brownie", 5, 0.8F));
    public static final RegistryObject<Item> PEANUT_BUTTER_BROWNIE = ITEMS.register("peanut_butter_brownie", () -> new DDFoodBase("peanut_butter_brownie", 5, 0.8F));
    public static final RegistryObject<Item> CARAMEL_BROWNIE = ITEMS.register("caramel_brownie", () -> new DDFoodBase("caramel_brownie", 5, 0.8F));
    public static final RegistryObject<Item> MINT_BROWNIE = ITEMS.register("mint_brownie", () -> new DDFoodBase("mint_brownie", 5, 0.8F));

    // ========== 太妃糖 ==========
    public static final RegistryObject<Item> TAFFY = ITEMS.register("taffy", () -> new DDCandyBase("taffy", 1, 0.3F, 10));
    public static final RegistryObject<Item> STRAWBERRY_TAFFY = ITEMS.register("strawberry_taffy", () -> new DDCandyBase("strawberry_taffy", 1, 0.3F, 10));
    public static final RegistryObject<Item> GREEN_APPLE_TAFFY = ITEMS.register("green_apple_taffy", () -> new DDCandyBase("green_apple_taffy", 1, 0.3F, 10));
    public static final RegistryObject<Item> BLUEBERRY_TAFFY = ITEMS.register("blueberry_taffy", () -> new DDCandyBase("blueberry_taffy", 1, 0.3F, 10));
    public static final RegistryObject<Item> BANANA_TAFFY = ITEMS.register("banana_taffy", () -> new DDCandyBase("banana_taffy", 1, 0.3F, 10));
    public static final RegistryObject<Item> CHERRY_TAFFY = ITEMS.register("cherry_taffy", () -> new DDCandyBase("cherry_taffy", 1, 0.3F, 10));

    // ========== Jolly Rancher ==========
    public static final RegistryObject<Item> STRAWBERRY_JOLLY_RANCHER = ITEMS.register("strawberry_jolly_rancher", () -> new DDCandyBase("strawberry_jolly_rancher", 1, 0.4F, 15));
    public static final RegistryObject<Item> GREEN_APPLE_JOLLY_RANCHER = ITEMS.register("green_apple_jolly_rancher", () -> new DDCandyBase("green_apple_jolly_rancher", 1, 0.4F, 15));
    public static final RegistryObject<Item> BLUEBERRY_JOLLY_RANCHER = ITEMS.register("blueberry_jolly_rancher", () -> new DDCandyBase("blueberry_jolly_rancher", 1, 0.4F, 15, "wubalube"));
    public static final RegistryObject<Item> BANANA_JOLLY_RANCHER = ITEMS.register("banana_jolly_rancher", () -> new DDCandyBase("banana_jolly_rancher", 1, 0.4F, 15));
    public static final RegistryObject<Item> CHERRY_JOLLY_RANCHER = ITEMS.register("cherry_jolly_rancher", () -> new DDCandyBase("cherry_jolly_rancher", 1, 0.4F, 15));

    // ========== 威化饼 ==========
    public static final RegistryObject<Item> VANILLA_WAFFER = ITEMS.register("vanilla_waffer", () -> new DDFoodBase("vanilla_waffer", 1, 0.3F));
    public static final RegistryObject<Item> CHOCOLATE_WAFFER = ITEMS.register("chocolate_waffer", () -> new DDFoodBase("chocolate_waffer", 1, 0.3F));
    public static final RegistryObject<Item> STRAWBERRY_WAFFER = ITEMS.register("strawberry_waffer", () -> new DDFoodBase("strawberry_waffer", 1, 0.3F));

    // ========== 千层蛋糕 ==========
    public static final RegistryObject<Item> VANILLA_TRIFLE = ITEMS.register("vanilla_trifle", () -> new DDFoodBase("vanilla_trifle", 8, 4.8F, "minecrafter4112"));
    public static final RegistryObject<Item> CHOCOLATE_TRIFLE = ITEMS.register("chocolate_trifle", () -> new DDFoodBase("chocolate_trifle", 8, 4.8F));

    // ========== 手指泡芙 ==========
    public static final RegistryObject<Item> VANILLA_FROSTED_ECLAIR = ITEMS.register("vanilla_frosted_eclair", () -> new DDFoodBase("vanilla_frosted_eclair", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_ECLAIR = ITEMS.register("chocolate_frosted_eclair", () -> new DDFoodBase("chocolate_frosted_eclair", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_ECLAIR = ITEMS.register("strawberry_frosted_eclair", () -> new DDFoodBase("strawberry_frosted_eclair", 4, 0.4F));

    // ========== 太妃糖 ==========
    public static final RegistryObject<Item> VANILLA_TOFFEE = ITEMS.register("vanilla_toffee", () -> new DDFoodBase("vanilla_toffee", 3, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_TOFFEE = ITEMS.register("chocolate_toffee", () -> new DDFoodBase("chocolate_toffee", 3, 0.4F));

    // ========== 更多棒棒糖 ==========
    public static final RegistryObject<Item> GREEN_APPLE_LOLLIPOP = ITEMS.register("green_apple_lollipop", () -> new DDCandyBase("green_apple_lollipop", 1, 0.2F, 8));
    public static final RegistryObject<Item> MELON_LOLLIPOP = ITEMS.register("melon_lollipop", () -> new DDCandyBase("melon_lollipop", 1, 0.2F, 8));

    // ========== 仙豆 ==========
    public static final RegistryObject<Item> SENZU_BEAN = ITEMS.register("senzu_bean", () -> new DDCandyBase("senzu_bean", 20, 20.0F, 8));

    // ========== 蛋糕卷 ==========
    public static final RegistryObject<Item> VANILLA_FROSTED_VANILLA_CAKE_ROLL = ITEMS.register("vanilla_frosted_vanilla_cake_roll", () -> new DDFoodBase("vanilla_frosted_vanilla_cake_roll", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_VANILLA_CAKE_ROLL = ITEMS.register("chocolate_frosted_vanilla_cake_roll", () -> new DDFoodBase("chocolate_frosted_vanilla_cake_roll", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_VANILLA_CAKE_ROLL = ITEMS.register("strawberry_frosted_vanilla_cake_roll", () -> new DDFoodBase("strawberry_frosted_vanilla_cake_roll", 4, 0.4F));
    public static final RegistryObject<Item> VANILLA_FROSTED_CHOCOLATE_CAKE_ROLL = ITEMS.register("vanilla_frosted_chocolate_cake_roll", () -> new DDFoodBase("vanilla_frosted_chocolate_cake_roll", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_CHOCOLATE_CAKE_ROLL = ITEMS.register("chocolate_frosted_chocolate_cake_roll", () -> new DDFoodBase("chocolate_frosted_chocolate_cake_roll", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_CHOCOLATE_CAKE_ROLL = ITEMS.register("strawberry_frosted_chocolate_cake_roll", () -> new DDFoodBase("strawberry_frosted_chocolate_cake_roll", 4, 0.4F));
    public static final RegistryObject<Item> MINT_FROSTED_CHOCOLATE_CAKE_ROLL = ITEMS.register("mint_frosted_chocolate_cake_roll", () -> new DDFoodBase("mint_frosted_chocolate_cake_roll", 4, 0.4F));
    public static final RegistryObject<Item> VANILLA_RED_VELVET_CAKE_ROLL = ITEMS.register("vanilla_red_velvet_cake_roll", () -> new DDFoodBase("vanilla_red_velvet_cake_roll", 4, 0.4F));
    public static final RegistryObject<Item> CHOCOLATE_RED_VELVET_CAKE_ROLL = ITEMS.register("chocolate_red_velvet_cake_roll", () -> new DDFoodBase("chocolate_red_velvet_cake_roll", 4, 0.4F));
    public static final RegistryObject<Item> STRAWBERRY_RED_VELVET_CAKE_ROLL = ITEMS.register("strawberry_red_velvet_cake_roll", () -> new DDFoodBase("strawberry_red_velvet_cake_roll", 4, 0.4F));

    // ========== 冰淇淋三明治 ==========
    public static final RegistryObject<Item> VANILLA_ICE_CREAM_SANDWICH = ITEMS.register("vanilla_ice_cream_sandwich", () -> new DDFoodBase("vanilla_ice_cream_sandwich", 4, 0.8F));
    public static final RegistryObject<Item> CHOCOLATE_ICE_CREAM_SANDWICH = ITEMS.register("chocolate_ice_cream_sandwich", () -> new DDFoodBase("chocolate_ice_cream_sandwich", 4, 0.8F));
    public static final RegistryObject<Item> STRAWBERRY_ICE_CREAM_SANDWICH = ITEMS.register("strawberry_ice_cream_sandwich", () -> new DDFoodBase("strawberry_ice_cream_sandwich", 4, 0.8F));
    public static final RegistryObject<Item> MINT_ICE_CREAM_SANDWICH = ITEMS.register("mint_ice_cream_sandwich", () -> new DDFoodBase("mint_ice_cream_sandwich", 4, 0.8F));
    public static final RegistryObject<Item> NEAPOLITAN_ICE_CREAM_SANDWICH = ITEMS.register("neapolitan_ice_cream_sandwich", () -> new DDFoodBase("neapolitan_ice_cream_sandwich", 4, 0.8F));

    // ========== 香蕉船圣代 ==========
    public static final RegistryObject<Item> BANANA_SPLIT_ICE_CREAM_SUNDAE = ITEMS.register("banana_split_ice_cream_sundae", () -> new DDFoodBase("banana_split_ice_cream_sundae", 8, 2.4F));
    public static final RegistryObject<Item> BANANA_SPLIT_ICE_CREAM_SUNDAE_SPRINKLES = ITEMS.register("banana_split_ice_cream_sundae_sprinkles", () -> new DDFoodBase("banana_split_ice_cream_sundae_sprinkles", 8, 2.4F));
    public static final RegistryObject<Item> BANANA_SPLIT_ICE_CREAM_SUNDAE_CHOCOLATE_SYRUP = ITEMS.register("banana_split_ice_cream_sundae_chocolate_syrup", () -> new DDFoodBase("banana_split_ice_cream_sundae_chocolate_syrup", 8, 2.4F));

    // ========== 缺失的巧克力涂层冰淇淋蛋筒 ==========
    public static final RegistryObject<Item> CHOCOLATE_MINT_CHOCOLATE_CHIP_ICE_CREAM_CONE = ITEMS.register("chocolate_mint_chocolate_chip_ice_cream_cone", () -> new DDFoodBase("chocolate_mint_chocolate_chip_ice_cream_cone", 7, 1.8F));

    // ========== 缺失的饼干 ==========
    public static final RegistryObject<Item> MM_COOKIE = ITEMS.register("mm_cookie", () -> new DDFoodBase("mm_cookie", 3, 0.4F));

    // ========== 缺失的冰棍 ==========
    public static final RegistryObject<Item> FIRECRACKER_POPSICLE = ITEMS.register("firecracker_popsicle", () -> new DDFoodBase("firecracker_popsicle", 1, 0.2F));

    // ========== 缺失的烤盘和盒子 ==========
    public static final RegistryObject<Item> EMPTY_CUPCAKE_TRAY = ITEMS.register("empty_cupcake_tray", () -> new DDItemBase("empty_cupcake_tray"));
    public static final RegistryObject<Item> EMPTY_JELLYBEAN_BOX = ITEMS.register("empty_jellybean_box", () -> new DDItemBase("empty_jellybean_box"));
    public static final RegistryObject<Item> LUNCH_BOX = ITEMS.register("lunch_box", () -> new DDItemBase("lunch_box"));
    public static final RegistryObject<Item> DONUT_BOX = ITEMS.register("donut_box", () -> new DDItemBase("donut_box"));
    public static final RegistryObject<Item> JELLYBEAN_BOX = ITEMS.register("jellybean_box", () -> new DDItemBase("jellybean_box"));

    // ========== 更多物品 ==========
    public static final RegistryObject<Item> HOT_CHOCOLATE_CUP = ITEMS.register("hot_chocolate_cup", () -> new DDDrinkBase("hot_chocolate_cup", 3, 2.4F, 16));
    public static final RegistryObject<Item> SYRUP_BOTTLE = ITEMS.register("syrup_bottle", () -> new DDItemBase("syrup_bottle"));
    public static final RegistryObject<Item> CHOCOLATE_SYRUP_BOTTLE = ITEMS.register("chocolate_syrup_bottle", () -> new DDItemBase("chocolate_syrup_bottle"));
    public static final RegistryObject<Item> STRAWBERRY_SYRUP_BOTTLE = ITEMS.register("strawberry_syrup_bottle", () -> new DDItemBase("strawberry_syrup_bottle"));

    // ========== 蛋糕方块物品 ==========
    public static final RegistryObject<Item> VANILLA_FROSTED_VANILLA_CAKE_ITEM = ITEMS.register("vanilla_frosted_vanilla_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.VANILLA_FROSTED_VANILLA_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_VANILLA_CAKE_ITEM = ITEMS.register("chocolate_frosted_vanilla_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.CHOCOLATE_FROSTED_VANILLA_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_VANILLA_CAKE_ITEM = ITEMS.register("strawberry_frosted_vanilla_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.STRAWBERRY_FROSTED_VANILLA_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> VANILLA_FROSTED_CHOCOLATE_CAKE_ITEM = ITEMS.register("vanilla_frosted_chocolate_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.VANILLA_FROSTED_CHOCOLATE_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> CHOCOLATE_FROSTED_CHOCOLATE_CAKE_ITEM = ITEMS.register("chocolate_frosted_chocolate_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.CHOCOLATE_FROSTED_CHOCOLATE_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> STRAWBERRY_FROSTED_CHOCOLATE_CAKE_ITEM = ITEMS.register("strawberry_frosted_chocolate_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.STRAWBERRY_FROSTED_CHOCOLATE_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> MINT_FROSTED_CHOCOLATE_CAKE_ITEM = ITEMS.register("mint_frosted_chocolate_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.MINT_FROSTED_CHOCOLATE_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> CHOCOLATE_MOUSSE_CAKE_ITEM = ITEMS.register("chocolate_mousse_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.CHOCOLATE_MOUSSE_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> VANILLA_CHEESE_CAKE_ITEM = ITEMS.register("vanilla_cheese_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.VANILLA_CHEESE_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> CHOCOLATE_CHEESE_CAKE_ITEM = ITEMS.register("chocolate_cheese_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.CHOCOLATE_CHEESE_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> COFFEE_CAKE_ITEM = ITEMS.register("coffee_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.COFFEE_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> VANILLA_RED_VELVET_CAKE_ITEM = ITEMS.register("vanilla_red_velvet_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.VANILLA_RED_VELVET_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> CHOCOLATE_RED_VELVET_CAKE_ITEM = ITEMS.register("chocolate_red_velvet_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.CHOCOLATE_RED_VELVET_CAKE.get(), new Item.Properties()));
    public static final RegistryObject<Item> SPONGE_CAKE_ITEM = ITEMS.register("sponge_cake", () -> new net.minecraft.world.item.BlockItem(DDBlockInit.SPONGE_CAKE.get(), new Item.Properties()));

    // ========== 盐物品 ==========
    public static final RegistryObject<Item> SALT = ITEMS.register("salt", () -> new DDItemBase("salt"));

    public static final RegistryObject<CreativeModeTab> DELICIOUS_DELIGHTS_TAB = CREATIVE_TABS.register("delicious_delights", () -> CreativeModeTab.builder()
            .icon(() -> new ItemStack(CHOCOLATE_BAR.get()))
            .title(Component.translatable("itemGroup.delicious_delights"))
            .displayItems((params, output) -> {
                ITEMS.getEntries().forEach(item -> output.accept(item.get()));
            })
            .build());

    public static void register() {
        // 注册已在 BloomFeastMainJava 中完成
    }
}

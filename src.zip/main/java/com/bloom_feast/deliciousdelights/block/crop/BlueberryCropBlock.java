package com.bloom_feast.deliciousdelights.block.crop;

import com.bloom_feast.deliciousdelights.init.DDItemInit;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.shapes.VoxelShape;

public class BlueberryCropBlock extends DDCropBlock {
    private static final VoxelShape[] SHAPES = new VoxelShape[]{
            Block.box(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D),
            Block.box(0.0D, 0.0D, 0.0D, 16.0D, 5.0D, 16.0D),
            Block.box(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D),
            Block.box(0.0D, 0.0D, 0.0D, 16.0D, 11.0D, 16.0D),
            Block.box(0.0D, 0.0D, 0.0D, 16.0D, 14.0D, 16.0D),
            Block.box(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D)
    };

    public BlueberryCropBlock() {
        super("blueberry_crop", 5, SHAPES, () -> DDItemInit.BLUEBERRY_SEEDS.get(), () -> DDItemInit.BLUEBERRY.get());
    }
}

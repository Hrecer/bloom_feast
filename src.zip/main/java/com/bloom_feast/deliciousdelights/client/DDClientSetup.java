package com.bloom_feast.deliciousdelights.client;

import com.bloom_feast.deliciousdelights.init.DDBlockInit;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = "bloom_feast", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class DDClientSetup {
    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        ItemBlockRenderTypes.setRenderLayer(DDBlockInit.TEA_CROP.get(), RenderType.cutout());
        ItemBlockRenderTypes.setRenderLayer(DDBlockInit.STRAWBERRY_CROP.get(), RenderType.cutout());
        ItemBlockRenderTypes.setRenderLayer(DDBlockInit.MINT_CROP.get(), RenderType.cutout());
        ItemBlockRenderTypes.setRenderLayer(DDBlockInit.RICE_CROP.get(), RenderType.cutout());
        ItemBlockRenderTypes.setRenderLayer(DDBlockInit.BLUEBERRY_CROP.get(), RenderType.cutout());
        ItemBlockRenderTypes.setRenderLayer(DDBlockInit.CHERRY_CROP.get(), RenderType.cutout());
        ItemBlockRenderTypes.setRenderLayer(DDBlockInit.GINGER_CROP.get(), RenderType.cutout());
        ItemBlockRenderTypes.setRenderLayer(DDBlockInit.BLACKBERRY_CROP.get(), RenderType.cutout());
        ItemBlockRenderTypes.setRenderLayer(DDBlockInit.ANISE_CROP.get(), RenderType.cutout());
    }
}
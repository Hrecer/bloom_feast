package com.bloom_feast.deliciousdelights.item.base;

import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class DDFoodBase extends Item {
    private final String specialThanks;

    public DDFoodBase(String name, int nutrition, float saturation) {
        super(new Properties()
                .food(new FoodProperties.Builder()
                        .nutrition(nutrition)
                        .saturationMod(saturation)
                        .build()));
        this.specialThanks = null;
    }

    public DDFoodBase(String name, int nutrition, float saturation, String specialThanks) {
        super(new Properties()
                .food(new FoodProperties.Builder()
                        .nutrition(nutrition)
                        .saturationMod(saturation)
                        .build()));
        this.specialThanks = specialThanks;
    }

    public DDFoodBase(String name, int nutrition, float saturation, int maxStackSize) {
        super(new Properties()
                .food(new FoodProperties.Builder()
                        .nutrition(nutrition)
                        .saturationMod(saturation)
                        .build())
                .stacksTo(maxStackSize));
        this.specialThanks = null;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
        if (specialThanks != null) {
            tooltipComponents.add(Component.translatable("text.special_thanks", specialThanks));
        }
        super.appendHoverText(stack, level, tooltipComponents, isAdvanced);
    }
}

package com.bloom_feast.deliciousdelights.item.base;

import com.bloom_feast.deliciousdelights.init.DDItemInit;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

public class DDDrinkBase extends Item {
    private final boolean isCoffee;
    private final boolean isMilk;
    private final int coffeeDuration;
    private final int coffeeAmplifier;

    public DDDrinkBase(String name, int nutrition, float saturation) {
        super(new Properties()
                .food(new FoodProperties.Builder()
                        .nutrition(nutrition)
                        .saturationMod(saturation)
                        .build())
                .craftRemainder(DDItemInit.EMPTY_CUP.get()));
        this.isCoffee = false;
        this.isMilk = false;
        this.coffeeDuration = 0;
        this.coffeeAmplifier = 0;
    }

    public DDDrinkBase(String name, int nutrition, float saturation, int maxStackSize) {
        super(new Properties()
                .food(new FoodProperties.Builder()
                        .nutrition(nutrition)
                        .saturationMod(saturation)
                        .build())
                .stacksTo(maxStackSize)
                .craftRemainder(DDItemInit.EMPTY_CUP.get()));
        this.isCoffee = false;
        this.isMilk = false;
        this.coffeeDuration = 0;
        this.coffeeAmplifier = 0;
    }

    public DDDrinkBase(String name, int nutrition, float saturation, boolean isCoffee, int coffeeDuration, int coffeeAmplifier) {
        super(new Properties()
                .food(new FoodProperties.Builder()
                        .nutrition(nutrition)
                        .saturationMod(saturation)
                        .build())
                .craftRemainder(DDItemInit.EMPTY_CUP.get()));
        this.isCoffee = isCoffee;
        this.isMilk = false;
        this.coffeeDuration = coffeeDuration;
        this.coffeeAmplifier = coffeeAmplifier;
    }

    public DDDrinkBase(String name, int nutrition, float saturation, boolean isMilk) {
        super(new Properties()
                .food(new FoodProperties.Builder()
                        .nutrition(nutrition)
                        .saturationMod(saturation)
                        .build())
                .craftRemainder(Items.GLASS_BOTTLE));
        this.isCoffee = false;
        this.isMilk = isMilk;
        this.coffeeDuration = 0;
        this.coffeeAmplifier = 0;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.DRINK;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entityLiving) {
        if (entityLiving instanceof Player player) {
            player.awardStat(Stats.ITEM_USED.get(this));

            if (player instanceof ServerPlayer serverPlayer) {
                CriteriaTriggers.CONSUME_ITEM.trigger(serverPlayer, stack);
            }
        }

        if (isCoffee && !level.isClientSide) {
            entityLiving.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, coffeeDuration, coffeeAmplifier, false, false));
        } else if (isMilk && !level.isClientSide) {
            entityLiving.removeAllEffects();
        }

        ItemStack container = new ItemStack(isMilk ? Items.GLASS_BOTTLE : DDItemInit.EMPTY_CUP.get());
        if (entityLiving instanceof Player player) {
            if (!player.getAbilities().instabuild) {
                if (stack.isEmpty()) {
                    return container;
                }
                if (!player.getInventory().add(container)) {
                    player.drop(container, false);
                }
            }
        }

        return super.finishUsingItem(stack, level, entityLiving);
    }
}

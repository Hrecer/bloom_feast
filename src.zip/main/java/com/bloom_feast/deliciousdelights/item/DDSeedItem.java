package com.bloom_feast.deliciousdelights.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

import java.util.function.Supplier;

public class DDSeedItem extends Item {
    private final Supplier<Block> cropBlockSupplier;

    public DDSeedItem(String name, Supplier<Block> cropBlockSupplier) {
        super(new Properties());
        this.cropBlockSupplier = cropBlockSupplier;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        BlockState state = level.getBlockState(pos);
        ItemStack stack = context.getItemInHand();

        Block cropBlock = cropBlockSupplier.get();
        if (cropBlock != null) {
            BlockPos placePos = pos.relative(context.getClickedFace());
            BlockState cropState = cropBlock.defaultBlockState();

            if (level.isEmptyBlock(placePos) && cropState.canSurvive(level, placePos)) {
                if (!level.isClientSide) {
                    level.setBlock(placePos, cropState, 3);
                    if (!context.getPlayer().getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return InteractionResult.PASS;
    }
}

package com.bloom_feast.fastfood.init;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;

public class ModFoods {

    public static final FoodProperties CUTTED_BREAD = baseFood(2, 2.0F);
    public static final FoodProperties POTATO_SLIDES = baseFood(1, 0.0F);
    public static final FoodProperties FRENCH_FRIES = baseFood(4, 0.0F);
    public static final FoodProperties RAW_BEEFPIE = baseFood(3, 0.0F);
    public static final FoodProperties COOKED_BEEFPIE = baseFood(8, 0.8F);
    public static final FoodProperties SPICY_CHICKEN = baseFood(8, 0.0F);
    public static final FoodProperties RAW_SPICY_CHICKEN = baseFood(3, 0.0F);
    public static final FoodProperties FRIED_EGG = baseFood(4, 0.0F);
    public static final FoodProperties SAUSAGE = baseFood(4, 0.0F);
    public static final FoodProperties FF_CHOCOLATE_BAR = foodWithEffect(7, 0.0F, speedEffect(600, 0));
    public static final FoodProperties AMERICAN_CHEESE = baseFood(2, 0.0F);
    public static final FoodProperties GRILLED_CHICKEN_BURGER = foodWithEffect(10, 0.8F, speedEffect(200, 0));

    public static final FoodProperties FINISH_CUSTOM_BURGER = new FoodProperties.Builder()
            .nutrition(16).saturationMod(1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 0), 1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 0), 1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.JUMP, 400, 0), 1.0F)
            .build();

    public static final FoodProperties SPRITE = drinkFood(3, 0.0F, speedEffect(200, 0));
    public static final FoodProperties DR_PEPPER = drinkFood(3, 0.0F, speedEffect(100, 0));
    public static final FoodProperties FANTA = drinkFood(3, 0.0F, speedEffect(200, 0));
    public static final FoodProperties FANTA_STRAWBERRY = drinkFood(4, 0.0F, speedEffect(300, 0));
    public static final FoodProperties COKE = drinkFood(3, 0.0F, speedEffect(200, 0));
    public static final FoodProperties APPLE_JUICE = drinkFood(4, 0.0F, speedEffect(200, 0));

    public static final FoodProperties FF_APPLE_PIE = new FoodProperties.Builder()
            .nutrition(8).saturationMod(0.0F)
            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0), 1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 200, 0), 1.0F)
            .build();

    public static final FoodProperties DOUBLE_BEEF_BURGER = new FoodProperties.Builder()
            .nutrition(16).saturationMod(1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 1), 1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 1200, 1), 1.0F)
            .build();

    public static final FoodProperties TRIPLE_BURGER = new FoodProperties.Builder()
            .nutrition(20).saturationMod(1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.NIGHT_VISION, 4800, 1), 1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 4800, 0), 1.0F)
            .build();

    public static final FoodProperties SPICY_POTATO_TACO = new FoodProperties.Builder()
            .nutrition(16).saturationMod(1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 3600, 1), 1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.NIGHT_VISION, 3600, 0), 1.0F)
            .build();

    public static final FoodProperties SPICY_CHICKEN_BURGER = new FoodProperties.Builder()
            .nutrition(16).saturationMod(1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.JUMP, 400, 1), 1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 400, 1), 1.0F)
            .build();

    public static final FoodProperties HOT_DOG = foodWithEffect(12, 0.5F, new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 7200, 0));

    public static final FoodProperties BACON_BURGER = new FoodProperties.Builder()
            .nutrition(14).saturationMod(1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 3600, 1), 1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.JUMP, 3600, 1), 1.0F)
            .build();

    private static FoodProperties baseFood(int nutrition, float saturation) {
        return new FoodProperties.Builder().nutrition(nutrition).saturationMod(saturation).build();
    }

    private static FoodProperties drinkFood(int nutrition, float saturation, MobEffectInstance effect) {
        return new FoodProperties.Builder().nutrition(nutrition).saturationMod(saturation)
                .effect(() -> effect, 1.0F).alwaysEat().build();
    }

    private static FoodProperties foodWithEffect(int nutrition, float saturation, MobEffectInstance effect) {
        return new FoodProperties.Builder().nutrition(nutrition).saturationMod(saturation)
                .effect(() -> effect, 1.0F).build();
    }

    private static MobEffectInstance speedEffect(int duration, int amplifier) {
        return new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, amplifier);
    }

    private static MobEffectInstance regenEffect(int duration, int amplifier) {
        return new MobEffectInstance(MobEffects.REGENERATION, duration, amplifier);
    }
}

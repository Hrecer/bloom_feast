package com.bloom_feast.fastfood.init;

import com.bloom_feast.BloomFeastMainJava;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(
            net.minecraft.core.registries.Registries.CREATIVE_MODE_TAB, BloomFeastMainJava.MOD_ID);

    public static final RegistryObject<CreativeModeTab> FASTFOOD_TAB = TABS.register("fastfood",
            () -> CreativeModeTab.builder()
                    .title(net.minecraft.network.chat.Component.literal("FastFood"))
                    .icon(() -> new ItemStack(ModItems.CUTTED_BREAD.get()))
                    .displayItems((params, output) -> {
                        ModItems.ITEMS.getEntries().forEach(item -> {
                            output.accept(item.get());
                        });
                    })
                    .build());
}

package com.bloom_feast.fastfood.init;

import com.bloom_feast.BloomFeastMainJava;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, BloomFeastMainJava.MOD_ID);

    private static final List<RegistryObject<Item>> FOOD_ITEMS = new ArrayList<>();

    public static final RegistryObject<Item> CUTTED_BREAD = registerFood("cut_bread", ModFoods.CUTTED_BREAD);
    public static final RegistryObject<Item> POTATO_SLIDES = registerFood("potato_slides", ModFoods.POTATO_SLIDES);
    public static final RegistryObject<Item> FRENCH_FRIES = registerFood("french_fries", ModFoods.FRENCH_FRIES);
    public static final RegistryObject<Item> RAW_BEEFPIE = registerFood("raw_beefpie", ModFoods.RAW_BEEFPIE);
    public static final RegistryObject<Item> COOKED_BEEFPIE = registerFood("cooked_beefpie", ModFoods.COOKED_BEEFPIE);
    public static final RegistryObject<Item> SPICY_CHICKEN = registerFood("spicy_chicken", ModFoods.SPICY_CHICKEN);
    public static final RegistryObject<Item> RAW_SPICY_CHICKEN = registerFood("raw_spicy_chicken", ModFoods.RAW_SPICY_CHICKEN);
    public static final RegistryObject<Item> SPRITE = registerFood("sprite", ModFoods.SPRITE);
    public static final RegistryObject<Item> DR_PEPPER = registerFood("dr_pepper", ModFoods.DR_PEPPER);
    public static final RegistryObject<Item> FANTA = registerFood("fanta", ModFoods.FANTA);
    public static final RegistryObject<Item> FANTA_STRAWBERRY = registerFood("fanta_strawberry", ModFoods.FANTA_STRAWBERRY);
    public static final RegistryObject<Item> COKE = registerFood("coke", ModFoods.COKE);
    public static final RegistryObject<Item> FRIED_EGG = registerFood("fried_egg", ModFoods.FRIED_EGG);
    public static final RegistryObject<Item> FF_APPLE_PIE = registerFood("ff_apple_pie", ModFoods.FF_APPLE_PIE);
    public static final RegistryObject<Item> APPLE_JUICE = registerFood("apple_juice", ModFoods.APPLE_JUICE);
    public static final RegistryObject<Item> SAUSAGE = registerFood("sausage", ModFoods.SAUSAGE);
    public static final RegistryObject<Item> KETCHUP = register("ketchup", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FF_CHOCOLATE_BAR = registerFood("ff_chocolate_bar", ModFoods.FF_CHOCOLATE_BAR);
    public static final RegistryObject<Item> AMERICAN_CHEESE = registerFood("american_cheese", ModFoods.AMERICAN_CHEESE);
    public static final RegistryObject<Item> DOUBLE_BEEF_BURGER = registerFood("double_beef_burger", ModFoods.DOUBLE_BEEF_BURGER);
    public static final RegistryObject<Item> TRIPLE_BURGER = registerFood("triple_burger", ModFoods.TRIPLE_BURGER);
    public static final RegistryObject<Item> SPICY_POTATO_TACO = registerFood("spicy_potato_taco", ModFoods.SPICY_POTATO_TACO);
    public static final RegistryObject<Item> BACON_BURGER = registerFood("bacon_burger", ModFoods.BACON_BURGER);
    public static final RegistryObject<Item> SPICY_CHICKEN_BURGER = registerFood("spicy_chicken_burger", ModFoods.SPICY_CHICKEN_BURGER);
    public static final RegistryObject<Item> GRILLED_CHICKEN_BURGER = registerFood("grilled_chicken_burger", ModFoods.GRILLED_CHICKEN_BURGER);
    public static final RegistryObject<Item> FINISH_CUSTOM_BURGER = registerFood("finish_custom_burger", ModFoods.FINISH_CUSTOM_BURGER);
    public static final RegistryObject<Item> HOT_DOG = registerFood("hot_dog", ModFoods.HOT_DOG);

    private static RegistryObject<Item> registerFood(String name, net.minecraft.world.food.FoodProperties food) {
        RegistryObject<Item> item = ITEMS.register(name, () -> new Item(new Item.Properties().food(food)));
        FOOD_ITEMS.add(item);
        return item;
    }

    private static RegistryObject<Item> register(String name, Supplier<Item> supplier) {
        return ITEMS.register(name, supplier);
    }

    public static List<RegistryObject<Item>> getFoodItems() {
        return FOOD_ITEMS;
    }
}

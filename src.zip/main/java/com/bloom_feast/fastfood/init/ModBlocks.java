package com.bloom_feast.fastfood.init;

import com.bloom_feast.BloomFeastMainJava;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, BloomFeastMainJava.MOD_ID);
}

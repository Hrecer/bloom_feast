package com.bloom_feast.bonnyfood;

import com.bloom_feast.bonnyfood.item.BFItems;
import com.bloom_feast.bonnyfood.tab.BFCreativeTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

public class BonnyFoodInit {
    
    public static void init() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        
        BFItems.ITEMS.register(modEventBus);
        BFCreativeTabs.CREATIVE_MODE_TABS.register(modEventBus);
    }
}

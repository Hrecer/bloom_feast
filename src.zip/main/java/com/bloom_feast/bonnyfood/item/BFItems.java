package com.bloom_feast.bonnyfood.item;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.HashMap;
import java.util.Map;

public class BFItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, "bloom_feast");
    
    private static final Map<String, RegistryObject<Item>> REGISTERED_ITEMS = new HashMap<>();
    
    public static final RegistryObject<Item> ACIDOPHILUS = registerFood("acidophilus", 4, 0.3f);
    public static final RegistryObject<Item> AIRAN = registerFood("airan", 3, 0.3f);
    public static final RegistryObject<Item> AJVAR = registerFood("ajvar", 3, 0.3f);
    public static final RegistryObject<Item> AMARETTI_DI_SARONNO = registerFood("amarettidisaronno", 4, 0.3f);
    public static final RegistryObject<Item> APRICOT = registerFood("apricot", 3, 0.3f);
    public static final RegistryObject<Item> AVOCADO = registerFood("avocado", 2, 0.3f);
    public static final RegistryObject<Item> BAGEL = registerFood("bagel", 3, 0.3f);
    public static final RegistryObject<Item> BAGUETTE = registerFood("baguette", 5, 0.3f);
    public static final RegistryObject<Item> BAKED_POTATO_WITH_CHEESE = registerFood("bakedpotatowithcheese", 6, 0.3f);
    public static final RegistryObject<Item> BALISH = registerFood("balish", 10, 0.3f);
    public static final RegistryObject<Item> BAMBOO_SNACK = registerFood("bamboosnack", 2, 0.3f);
    public static final RegistryObject<Item> BAURSAK = registerFood("baursak", 3, 0.3f);
    public static final RegistryObject<Item> BAY_LEAF = registerItem("bayleaf");
    public static final RegistryObject<Item> BEEF_AZU = registerFood("beefazu", 6, 0.3f);
    public static final RegistryObject<Item> BEEF_CUTLET_WRAPPED_IN_BACON = registerFood("beefcutletwrappedinbacon", 5, 0.3f);
    public static final RegistryObject<Item> BELYASH = registerFood("belyash", 6, 0.3f);
    public static final RegistryObject<Item> BENJAMINS_BLEND = registerFood("benjaminsblend", 2, 0.3f, 1);
    public static final RegistryObject<Item> BLUE_ONION = registerFood("blueonion", 1, 0.3f);
    public static final RegistryObject<Item> BOILED_EGG = registerFood("boiledegg", 3, 0.3f);
    public static final RegistryObject<Item> BOILING_MILK = registerFood("boilingmilk", 1, 0.3f);
    public static final RegistryObject<Item> BOZBASH = registerFood("bozbash", 7, 0.3f);
    public static final RegistryObject<Item> BRIE = registerFood("brie", 5, 0.3f);
    public static final RegistryObject<Item> BRIN_D_AMOUR = registerFood("brindamour", 5, 0.3f);
    public static final RegistryObject<Item> BUTTER = registerFood("bf_butter", 1, 0.3f);
    public static final RegistryObject<Item> BUTTERSCOTCH_PIE = registerFood("butterscotchpie", 6, 0.3f);
    public static final RegistryObject<Item> CACAO_BUTTER = registerFood("cacaobutter", 1, 0.3f);
    public static final RegistryObject<Item> CAMBOZOLA = registerFood("cambozola", 5, 0.3f);
    public static final RegistryObject<Item> CELERY_STALK = registerFood("celerystalk", 1, 0.3f);
    public static final RegistryObject<Item> CHEESE = registerFood("bf_cheese", 4, 0.3f);
    public static final RegistryObject<Item> CHEESE_2 = registerFood("hard_cheese", 4, 0.3f);
    public static final RegistryObject<Item> CHEESE_GARLIC_BAGUETTE = registerFood("cheesegarlicbaguette", 6, 0.3f);
    public static final RegistryObject<Item> CHEESE_IN_ASH = registerFood("cheeseinash", 5, 0.3f);
    public static final RegistryObject<Item> CHEESECAKE = registerFood("cheesecake", 8, 0.3f);
    public static final RegistryObject<Item> CHICKEN_NUGGET = registerFood("chickennugget", 3, 0.3f);
    public static final RegistryObject<Item> CHILI_PEPPER = registerFood("chilipepper", 1, 0.3f);
    public static final RegistryObject<Item> CHILLI_SEEDS = registerItem("chilliseeds");
    public static final RegistryObject<Item> CHOCOLATE = registerFood("chocolate", 3, 0.3f);
    public static final RegistryObject<Item> CHOCOLATE_BUTTER = registerFood("chocolatebutter", 2, 0.3f);
    public static final RegistryObject<Item> CHOCOLATE_LIQUOR = registerItem("chocolateliquor");
    public static final RegistryObject<Item> CHOCOLATE_POTATO = registerFood("chocolatepotato", 3, 0.3f);
    public static final RegistryObject<Item> CHOCOLATE_POTATO_COCONUT = registerFood("chocolatepotatococonut", 4, 0.3f);
    public static final RegistryObject<Item> CHOCOLATE_SALAMI = registerFood("chocolatesalami", 6, 0.3f);
    public static final RegistryObject<Item> CINNAMON = registerItem("cinnamon");
    public static final RegistryObject<Item> CINNAMON_DUST = registerItem("cinnamondust");
    public static final RegistryObject<Item> COCONUT = registerFood("coconut", 2, 0.3f);
    public static final RegistryObject<Item> CONDENSED_MILK = registerFood("condensedmilk", 1, 0.3f);
    public static final RegistryObject<Item> CORN_STARCH = registerItem("cornstarch");
    public static final RegistryObject<Item> COTTAGE_CHEESE = registerFood("cottagecheese", 3, 0.3f);
    public static final RegistryObject<Item> CUCUMBER = registerFood("cucumber", 1, 0.3f);
    public static final RegistryObject<Item> CUSTARD = registerFood("custard", 2, 0.3f);
    public static final RegistryObject<Item> DOG_WITHOUT_HOT = registerFood("dogwithouthot", 3, 0.3f);
    public static final RegistryObject<Item> DORBLU = registerFood("dorblu", 5, 0.3f);
    public static final RegistryObject<Item> DRIED_MARJORAM = registerItem("driedmarjoram");
    public static final RegistryObject<Item> DUTCH_CHEESE = registerFood("dutchcheese", 5, 0.3f);
    public static final RegistryObject<Item> EGG_STUFFED_WITH_COD = registerFood("eggstuffedwithcod", 5, 0.3f);
    public static final RegistryObject<Item> EGGPLANT = registerFood("eggplant", 1, 0.3f);
    public static final RegistryObject<Item> FAT_BAGEL = registerFood("fatbagel", 4, 0.3f);
    public static final RegistryObject<Item> FRIED_LEMON = registerFood("friedlemon", 2, 0.3f);
    public static final RegistryObject<Item> FRIED_LEMON_PIECE = registerFood("friedlemonpiece", 1, 0.3f);
    public static final RegistryObject<Item> GARLIC = registerFood("garlic", 1, 0.3f);
    public static final RegistryObject<Item> GELO_DI_MELONE = registerFood("gelodimelone", 4, 0.3f);
    public static final RegistryObject<Item> GEORGIAN_LAMB_SHISH_KEBAB = registerFood("georgianlambshishkebab", 6, 0.3f);
    public static final RegistryObject<Item> GROUND_BASIL = registerItem("groundbasil");
    public static final RegistryObject<Item> HALLOUMI = registerFood("halloumi", 5, 0.3f);
    public static final RegistryObject<Item> HALVA = registerFood("halva", 3, 0.3f);
    public static final RegistryObject<Item> HONEY_PANCAKE = registerFood("honeypancake", 4, 0.3f);
    public static final RegistryObject<Item> HONEY_SALMON = registerFood("honeysalmon", 7, 0.3f);
    public static final RegistryObject<Item> HOT_DOG = registerFood("bf_hotdog", 5, 0.3f);
    public static final RegistryObject<Item> HOT_DOG_IN_MUSTARD_AND_KETCHUP = registerFood("hotdoginmustardandketchup", 7, 0.3f);
    public static final RegistryObject<Item> HOT_WITHOUT_DOG = registerFood("hotwithoutdog", 2, 0.3f);
    public static final RegistryObject<Item> KEFIR = registerFood("kefir", 2, 0.3f);
    public static final RegistryObject<Item> KETCHUP = registerFood("bf_ketchup", 1, 0.3f);
    public static final RegistryObject<Item> KULICH = registerFood("kulich", 5, 0.3f);
    public static final RegistryObject<Item> LEMON = registerFood("lemon", 1, 0.3f);
    public static final RegistryObject<Item> LEMON_JUICE = registerFood("lemonjuice", 2, 0.3f);
    public static final RegistryObject<Item> LEMON_WITH_SUGAR = registerFood("lemonwithsugar", 2, 0.3f);
    public static final RegistryObject<Item> LIME = registerFood("lime", 1, 0.3f);
    public static final RegistryObject<Item> LONG_LOAF = registerFood("longloaf", 5, 0.3f);
    public static final RegistryObject<Item> MARSENTAL = registerFood("marsental", 5, 0.3f);
    public static final RegistryObject<Item> MASCARPONE = registerFood("mascarpone", 5, 0.3f);
    public static final RegistryObject<Item> MAYONNAISE = registerFood("mayonnaise", 2, 0.3f);
    public static final RegistryObject<Item> MOLASSES = registerItem("molasses");
    public static final RegistryObject<Item> MONSTER_CANDY = registerFood("monstercandy", 1, 0.3f);
    public static final RegistryObject<Item> MOZZARELLA = registerFood("mozzarella", 5, 0.3f);
    public static final RegistryObject<Item> MUSTARD = registerFood("mustard", 1, 0.3f);
    public static final RegistryObject<Item> MUSTARD_SEEDS = registerItem("mustardseeds");
    public static final RegistryObject<Item> MUTTON_AZU = registerFood("muttonazu", 6, 0.3f);
    public static final RegistryObject<Item> MUTTON_BESHBARMAK = registerFood("muttonbeshbarmak", 4, 0.3f);
    public static final RegistryObject<Item> NUTMEG = registerFood("nutmeg", 1, 0.3f);
    public static final RegistryObject<Item> OHAGI = registerFood("ohagi", 3, 0.3f);
    public static final RegistryObject<Item> OLIVE = registerFood("olive", 1, 0.3f);
    public static final RegistryObject<Item> OLIVE_OIL_IN_A_BOTTLE = registerFood("oliveoilinabottle", 1, 0.3f);
    public static final RegistryObject<Item> ONION = registerFood("onion", 1, 0.3f);
    public static final RegistryObject<Item> ORANGE = registerFood("orange", 1, 0.3f);
    public static final RegistryObject<Item> OREO_COOKIE = registerFood("oreocookie", 2, 0.3f);
    public static final RegistryObject<Item> PANCAKE = registerFood("bf_pancake", 2, 0.3f);
    public static final RegistryObject<Item> PARMESAN = registerFood("parmesan", 5, 0.3f);
    public static final RegistryObject<Item> PEACH = registerFood("peach", 1, 0.3f);
    public static final RegistryObject<Item> PIEROGI = registerFood("pierogi", 6, 0.3f);
    public static final RegistryObject<Item> PINEAPPLE = registerFood("pineapple", 2, 0.3f);
    public static final RegistryObject<Item> PINK_CUSTARD = registerFood("pinkcustard", 4, 0.3f);
    public static final RegistryObject<Item> PORK_AZU = registerFood("porkazu", 6, 0.3f);
    public static final RegistryObject<Item> POTATO_CHIPS = registerFood("potatochips", 2, 0.3f);
    public static final RegistryObject<Item> POTATO_STARCH = registerItem("bf_potatostarch");
    public static final RegistryObject<Item> PROCESSED_CHEESE = registerFood("processedcheese", 5, 0.3f);
    public static final RegistryObject<Item> RAINBOW_COOKIE = registerFood("rainbowcookie", 4, 0.3f);
    public static final RegistryObject<Item> RICCIARELLI = registerFood("ricciarelli", 3, 0.3f);
    public static final RegistryObject<Item> ROQUEFORT = registerFood("roquefort", 5, 0.3f);
    public static final RegistryObject<Item> RUSSIAN_ROQUEFORT = registerFood("russianroquefort", 5, 0.3f);
    public static final RegistryObject<Item> SALO = registerFood("salo", 5, 0.3f);
    public static final RegistryObject<Item> SAMEMBERT = registerFood("samembert", 5, 0.3f);
    public static final RegistryObject<Item> SAUSAGE = registerFood("bf_sausage", 6, 0.3f);
    public static final RegistryObject<Item> SLICE_OF_LEMON = registerFood("sliceoflemon", 0, 0.3f);
    public static final RegistryObject<Item> SOUR_CREAM = registerFood("sourcream", 2, 0.3f);
    public static final RegistryObject<Item> SOUR_MILK = registerFood("sourmilk", 2, 0.3f);
    public static final RegistryObject<Item> SOY_SAUCE = registerItem("soysauce");
    public static final RegistryObject<Item> SOYA_BEANS = registerFood("soyabeans", 1, 0.3f);
    public static final RegistryObject<Item> SQUIRTING_CUCUMBER = registerFood("squirtingcucumber", 1, 0.3f);
    public static final RegistryObject<Item> SUNFLOWER_SEED = registerFood("sunflowerseed", 1, 0.3f);
    public static final RegistryObject<Item> SUSHKA = registerFood("sushka", 1, 0.3f);
    public static final RegistryObject<Item> TARTUFO_DI_PIZZO = registerFood("tartufodipizzo", 4, 0.3f);
    public static final RegistryObject<Item> TETE_DE_MOINE = registerFood("tetedemoine", 5, 0.3f);
    public static final RegistryObject<Item> TOFFEE = registerFood("toffee", 2, 0.3f);
    public static final RegistryObject<Item> TOMATO = registerFood("tomato", 1, 0.3f);
    public static final RegistryObject<Item> TOMATO_PASTE = registerFood("tomatopaste", 4, 0.3f);
    public static final RegistryObject<Item> TOMATO_PUREE = registerFood("tomatopuree", 4, 0.3f);
    public static final RegistryObject<Item> TREVISIO = registerFood("treviso", 5, 0.3f);
    public static final RegistryObject<Item> UKHA = registerFood("ukha", 6, 0.3f);
    public static final RegistryObject<Item> VATRUSHKA = registerFood("vatrushka", 4, 0.3f);
    public static final RegistryObject<Item> VEGETABLE_OIL_IN_A_BOTTLE = registerFood("vegetableoilinabottle", 0, 0.3f);
    public static final RegistryObject<Item> WATERMELON_COCKTAIL = registerFood("watermeloncocktail", 4, 0.3f);
    public static final RegistryObject<Item> WATERMELON_JAM = registerFood("watermelonjam", 5, 0.3f);
    public static final RegistryObject<Item> WATERMELON_JUICE = registerFood("watermelonjuice", 3, 0.3f);
    public static final RegistryObject<Item> WATERMELON_LEMONADE = registerFood("watermelonlemonade", 4, 0.3f);
    public static final RegistryObject<Item> WATERMELON_PANA_COTTA = registerFood("watermelonpanacotta", 5, 0.3f);
    public static final RegistryObject<Item> ZEPPOLE = registerFood("zeppole", 2, 0.3f);
    public static final RegistryObject<Item> ZUCCHINI = registerFood("zucchini", 1, 0.3f);
    public static final RegistryObject<Item> ZUCCHINI_FRITTERS = registerFood("zucchinifritters", 2, 0.3f);
    
    private static RegistryObject<Item> registerFood(String name, int nutrition, float saturation) {
        return registerFood(name, nutrition, saturation, 64);
    }
    
    private static RegistryObject<Item> registerFood(String name, int nutrition, float saturation, int maxStackSize) {
        RegistryObject<Item> item = ITEMS.register(name, () -> new Item(new Item.Properties()
                .food(new net.minecraft.world.food.FoodProperties.Builder()
                        .nutrition(nutrition)
                        .saturationMod(saturation)
                        .build())
                .stacksTo(maxStackSize)));
        REGISTERED_ITEMS.put(name, item);
        return item;
    }
    
    private static RegistryObject<Item> registerItem(String name) {
        RegistryObject<Item> item = ITEMS.register(name, () -> new Item(new Item.Properties()
                .stacksTo(64)));
        REGISTERED_ITEMS.put(name, item);
        return item;
    }
    
    public static Map<String, RegistryObject<Item>> getRegisteredItems() {
        return REGISTERED_ITEMS;
    }
}
